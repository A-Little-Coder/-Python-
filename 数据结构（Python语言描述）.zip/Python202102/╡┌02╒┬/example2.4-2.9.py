# 2.3 p48
def reverse(alst):
    """ 将列表alst中的元素进行逆置，如将[1,2,3,4]逆置为[4,3,2,1] """
    i = 0   # i指向alst列表最左端元素
    j = len(alst)-1    # j指向alst列表最右端元素
    while i < j:
        alst[i], alst[j] = alst[j], alst[i]  # 列表i号元素与j号元素交换
        i += 1      # i右移
        j -= 1      # j左移

alst =[4,3,2,1]
reverse(alst)
print(alst)


# p56
def mult(m1, m2):
    n = len(m1)                                    # O(1)
    m = [[0 for i in range(n)] for j in range(n)]  # O(n2)
    for i in range(n):                             # O(n)
        for j in range(n):                         # O(n)
            x = 0                                  # O(1)
            for k in range(n):
                x += m1[i][k] * m2[k][j]            # O(n)
            m[i][j] = x                             # O(1)
    return m                                        # O(1)

