# 2.1.2 p44
from AbstractContainer import AbstractContainer
class AContainer(AbstractContainer):

    def __init__(self, source=[]):
        self.data = source

    def size(self):
        return len(self.data)

    def empty(self):
        return len(self.data) == 0

    def insert(self, key):
        self.data.append(key)

    def contains(self, item):
       return item in self.data

    def remove(self, key):
        return self.data.remove(key)

    def clear(self):
        self.data.clear()

    def output(self):
        print(self.data)


a = AContainer([3,4])
a.insert(5)
a.insert(6)
a.remove(4)
a.output()
a.clear()
a.output()