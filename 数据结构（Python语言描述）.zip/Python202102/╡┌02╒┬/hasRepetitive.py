# 2.3.3  p58-59
import time
import random
import matplotlib.pyplot as plt

def has_repetitive1(lst):
    for i in range(0, len(lst)):
        for j in range(i+1, len(lst)):
            if lst[i] == lst[j]:
                return True
    return False


def has_repetitive2(lst):
    blst = sorted(lst)   # 原表被修改成有序表
    for i in range(0, len(blst)-1):
        if blst[i] == blst[i+1]:
            return True
    return False


def has_repetitive3(lst):  # list中的元素必须是不可变类型
    return len(lst) != len(set(lst))


def has_repetitive4(lst):  # list中的元素必须是不可变类型
    d = dict()
    for v in lst:
        d[v] = d.get(v, 0) + 1
        if d[v] > 1:
            return True
    return False



lst1 = []
lst2 = []
lst3 = []
lst4 = []

def compare(size,rand):
    funcs = [has_repetitive1, has_repetitive2, has_repetitive3,has_repetitive4]
    lst = [lst1,lst2,lst3,lst4]
    if rand:
        test = [random.randint(1, size*5) for i in range(size)]
    else:
        test = [i for i in range(size)]
    for i in range(len(funcs)):
        t0 = time.perf_counter()
        funcs[i](test)
        t1 = time.perf_counter()
        lst[i].append(t1-t0)


def main(rand):
    # start = 10000
    # end = 100000
    # step = 1000
    start = 1000
    end = 3001
    step = 20
    listLength = [i for i in range(start, end,step)]
    for i in range(start, end, step):
         compare(i,rand)
    plt.plot(listLength,lst1,"r",listLength,lst2,"b",listLength,lst3,"g",listLength,lst4,"p")
    plt.title('find -sort - set  -dict ')
    plt.legend(['find','sort','set','dict'])
    plt.show()



f1 = []
f2 = []
f3 = []
f4 = []

def main_2(listsize,rand):

    for j in range(5):
        if rand:
            blist = [random.randint(1, listsize) for i in range(listsize)]
        else:
            blist = [i for i in range(listsize)]
        blist[listsize-1] = 1
        start = time.perf_counter()
        has_repetitive1(blist)
        end = time.perf_counter()
        f1.append(end-start)

        start = time.perf_counter()
        has_repetitive2(blist)
        end = time.perf_counter()
        f2.append(end - start)

        start = time.perf_counter()
        has_repetitive3(blist)
        end = time.perf_counter()
        f3.append(end - start)

        start = time.perf_counter()
        has_repetitive4(blist)
        end = time.perf_counter()
        f4.append(end - start)
    print("搜索法")
    print(f1)
    print("排序法")
    print(f2)
    print("集合法")
    print(f3)
    print("字典法")
    print(f4)

main(False)
main_2(100000,False)