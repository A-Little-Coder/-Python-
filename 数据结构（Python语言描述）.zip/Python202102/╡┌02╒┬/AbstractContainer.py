# 2.1.2 p43
from abc import ABCMeta, abstractmethod


class AbstractContainer(metaclass=ABCMeta):
    """抽象容器类
    metaclass=ABCMeta表示将AbstracContainer类作为ABCMeta的子类
    继承于abc.ABCMeta的类可以使用abstractproperty和abstractmethod修饰器声明虚属性与虚方法"""

    @abstractmethod
    def __init__(self):
        """返回容器中元素的个数"""

    @abstractmethod
    def size(self):
        """返回容器中元素的个数"""

    @abstractmethod
    def empty(self):
        """判断容器是否为空"""


    @abstractmethod
    def insert(self, item):
        """在容器中放入元素item """

    @abstractmethod
    def remove(self, item):
        """ 在容器中删除元素item"""

    @abstractmethod
    def contains(self, item):
        """判断容器中是否包含元素item"""

    @abstractmethod
    def clear(self):
        """清空容器中的所有元素"""

    @abstractmethod
    def output(self):
        """ 输出容器中的所有元素"""


