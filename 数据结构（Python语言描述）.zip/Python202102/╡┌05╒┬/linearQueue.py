# 5.3.1 p145
class LinearQueue:

    def __init__(self, cap=6):
        self._capacity = cap
        self._entry = [None for x in range(0, self._capacity)]
        self._front = 0
        self._rear = -1

    def empty(self):
        return self._front > self._rear

    def __len__(self):
        return self._rear - self._front+1

    def append(self, item):
        if self._rear >= self._capacity - 1:
            raise Exception("overflow")
        else:
            self._rear += 1
            self._entry[self._rear] = item

    def serve(self):
        if self.empty():
            return None
        else:
            x = self._entry[self._front]
            self._front += 1
            return x

    def retrieve(self):
        if self.empty():
            return None
        else:
            return self._entry[self._front]


if __name__=="__main__":
    sq = LinearQueue()
    for i in range(6):
        sq.append(i)
    print(len(sq))
    print(sq.retrieve())

    print(sq.serve())
    # sq.append(7)
    # sq.append(7)
    print(sq.serve())
    print(sq.serve())
    # print(sq.serve())
    # print(sq.serve())
    # print(sq.serve())
    # print(sq.serve())
    print(len(sq))