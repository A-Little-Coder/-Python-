# 5.4 p150
class QueueNode:
    def __init__(self, data, link=None):
        self.entry = data
        self.next = link