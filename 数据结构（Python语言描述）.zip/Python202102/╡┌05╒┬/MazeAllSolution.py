# 5.5.3 用队列实现迷宫 p161-162
# 6.3.2 用栈实现迷宫 p185-186
import turtle

DIRECTIONS = [(0, 1), (1, 0), (0, -1), (-1, 0)]
              # 右    #下      # 左    # 上
# DIRECTIONS = [(-1, 0),(0, 1), (1, 0), (0, -1) ]
             # 上 # 右    #下      # 左

#DIRECTIONS = [(0, -1), (-1, 0),(0, 1), (1, 0) ]
            # 左  #  上 # 右    #下

PASSABLE = 0
OBSTACLE = 1
TRIED = 2
DEAD_END = 1
PATH_PART = 0

RIGHT = 0
DOWN = 1
LEFT = 2
UP = 3

BIG = 15

from ArrayStack import  ArrayStack
from CircularQueue import CircularQueue

class Maze:

    def isExit(self, position):
        return position == self.endPosition

    def isPassable(self, position):
        return self.mazeList[position[0]][position[1]] \
               == PASSABLE

    def __getitem__(self,idx):
        return self.mazeList[idx]

    def __init__(self, source, start, end):
        rowsInMaze = len(source)
        columnsInMaze = len(source[0])
        self.mazeList = [[None for j in range(columnsInMaze)]
                         for i in range(rowsInMaze)]
        for i in range(rowsInMaze):
            for j in range(columnsInMaze):
                self.mazeList[i][j] = source[i][j]
        self.startPosition = start
        self.endPosition = end
        self.rowsInMaze = rowsInMaze
        self.columnsInMaze = columnsInMaze
        # self.xTranslate = -columnsInMaze/2
        # self.yTranslate = rowsInMaze/2
        self.t = turtle.Turtle()
        self.t.shape('turtle')
        self.wn = turtle.Screen()
        self.wn.setup(800, 800)
        self.wn.setworldcoordinates(0, self.rowsInMaze, self.columnsInMaze, 0)

    def print_maze(self):
        for i in range(self.rowsInMaze):
            for j in range(self.columnsInMaze):
                print(self.mazeList[i][j], end=" ")
            print()

    def drawMaze(self):
        self.t.speed(100)
        for y in range(self.rowsInMaze):
            for x in range(self.columnsInMaze):
                if self.mazeList[y][x] == OBSTACLE:
                    self.drawCenteredBox(x, y, 'red')
        self.t.color('black')
        self.t.fillcolor('blue')

    def drawCenteredBox(self, x, y, color):
        self.t.up()
        self.t.goto(x, y)
        self.t.color(color)
        self.t.fillcolor(color)
        self.t.down()
        self.t.begin_fill()
        for i in range(4):
            # 设置海龟头朝向
            self.t.setheading(90 * i)
            self.t.forward(1)
        self.t.end_fill()

    def gotoStart(self, x, y):
        self.t.up()
        self.t.hideturtle()
        self.t.setposition(y + 0.5, x + 0.5)
        self.t.showturtle()

    def dropPowder(self,color,size=10):
       self.t.dot(size, color)

    def updatePosition(self, row, col, val):
        self.mazeList[row][col] = val
        self.moveTurtle(col, row)
        size = 10
        if val == PATH_PART:
            color = 'gray'
            size = 15
        elif val == OBSTACLE:
            color = 'red'
        elif val == DEAD_END:
            color = 'red'
        elif val == TRIED:
            color = 'black'
        self.drawDot(color, size)

    def moveTurtle(self, x, y):
        # if up:
        #     self.t.up()
        # else:
        self.t.down()
        self.t.setheading(self.t.towards(x+0.5, y+0.5))
        self.t.speed(1)
        self.t.goto(x+0.5, y+0.5)

    def drawDot(self, color, size=10):
        self.t.dot(size, color)

    def findRouteByStack(self):
        position = self.startPosition  # 从迷宫入口开始试探
        if self[position[0]][position[1]] == OBSTACLE:
            print("入口不通")
            return
        st = ArrayStack()
        nextDirection = 0
        while not self.isExit(position):  # 当position不是出口位置时循环执行
            # 对当前位置做已走过标记：做黑色圆点标记
            self.updatePosition(position[0], position[1], TRIED)
            for i in range(nextDirection, 4):
                # 依次获取position的i方向邻居nextPosition
                nextPosition = (position[0] + DIRECTIONS[i][0],
                                position[1] + DIRECTIONS[i][1])
                if self.isPassable(nextPosition):  # 如nextPosition位置可通且未走过
                    # 将原位置及下一可探测方向入栈
                    st.push((position, i + 1))
                    # 从nextPosition的 0（右）方向开始探测
                    position = nextPosition
                    nextDirection = 0
                    break
            else:  # position没有可通邻居，说明position位置不通，做红色圆点标记
                self.updatePosition(position[0], position[1], DEAD_END)
                if not st.empty():  # 栈非空，从出栈的位置及其方向继续探测
                    position, nextDirection = st.pop()
                else:  # 没有可回溯位置，迷宫没有路径，返回
                    print("没有找到通过迷宫的路径")
                    return False
        # 到达终点，输出路径
        st.push((position, 0))  # 终点入st栈
        while not st.empty():
            # 对每个出栈的位置，做灰色大圆点标记
            position = st.pop()[0]
            self.updatePosition(position[0], position[1], PATH_PART)
        self.wn.exitonclick()
        return

    def buildPath(self, precedent):
        """根据precedent中的位置前驱信息，产生起点到终点的路径存储到列表path中，
        同时将路径上的各个位置做灰色大圆点标记 """
        start = self.startPosition
        end = self.endPosition
        path = [end]
        pos = end
        while pos != start:
            self.updatePosition(pos[0], pos[1], PATH_PART)
            path.append(pos)
            pos = precedent[pos]
        path.append(start)  # 此时得到的是end到start的路径
        self.updatePosition(start[0], start[1], PATH_PART)
        self.wn.exitonclick()
        path.reverse()    # 列表逆置
        return path


    def findRouteByQueue(self):
        pos = self.startPosition
        if self[pos[0]][pos[1]] == OBSTACLE:
            print("入口不通")
            return
        if self.isExit(pos):						# 起点即为终点
            print("入口即出口")
            return [pos]
        q = CircularQueue()					# 建立辅助队列q
        precedent = dict()  # 创建各位置的前驱字典precedent
        # 小乌龟移动到pos位置，做黑色圆点标记
        self.updatePosition(pos[0], pos[1], TRIED)
        q.append(pos)  # 将起点入队
        while not q.empty():					# 队列非空时
            pos = q.serve()						# 出队一个位置
            self.gotoStart(pos[0], pos[1])      # 小乌龟移动到pos位置，不显示轨迹
            for i in range(4):					# 依次试探它的四个邻居nextPos
                nextPos = (pos[0] + DIRECTIONS[i][0],
                           pos[1] + DIRECTIONS[i][1])
                if self.isPassable(nextPos):				# 如果该邻居可通
                    # 小乌龟移动到nextPos位置，做黑色圆点标记
                    self.updatePosition(nextPos[0], nextPos[1], TRIED)
                    if self.isExit(nextPos):				# 如已经到达出口
                        precedent[nextPos] = pos		# 出口位置的前驱位置为pos
                        return self.buildPath(precedent)  # 完成路径输出
                    q.append(nextPos)					# 该邻居位置入队
                    precedent[nextPos] = pos			# 该邻居的前驱位置设为pos
                    self.gotoStart(pos[0], pos[1])			# 小乌龟回到pos，不显示轨迹
        print("没有找到通过迷宫的路径")

    def recFindRoute(self, start):   # p185 递归求解
        if self[start[0]][start[1]] == OBSTACLE:
            return False
        if self.isExit(start):
            self.updatePosition(start[0], start[1], PATH_PART)
            return True
        if self[start[0]][start[1]] == TRIED or self[start[0]][start[1]] == DEAD_END:
            return False
        self.updatePosition(start[0], start[1], TRIED)
        found = False
        i = 0
        while i < 4 and not found:  # 只要发现有一个邻居可到达出口，即退出循环
            neighbour = (start[0] + DIRECTIONS[i][0], start[1] + DIRECTIONS[i][1])
            found = self.recFindRoute(neighbour)
            i += 1
        if found:
            self.updatePosition(start[0], start[1], PATH_PART)
            return True
        else:
            self.updatePosition(start[0], start[1], DEAD_END)
            return False


if __name__ == "__main__":

    maze1 = [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1],
            [1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1],
            [1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1],
            [1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1],
            [1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1],
            [1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1],
            [1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

    maze2 = [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1],
            [1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1],
            [1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1],
            [1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1],
            [1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1],
            [1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1],
            [1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

    start = (1, 4)
    end = (10, 10)
    myMaze = Maze(maze1, start, end)
    myMaze.drawMaze()
    myMaze.gotoStart(start[0], start[1])
    #myMaze.findRouteByStack()
    myMaze.findRouteByQueue()
    #myMaze.recFindRoute(start)
    myMaze.print_maze()

