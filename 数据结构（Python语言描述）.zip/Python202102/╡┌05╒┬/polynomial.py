# 5.5.2 p155-158
from LinkedQueue import  LinkedQueue


class Term:

    def __init__(self, scalar=0.0, exponent=0):
        self.coefficient = scalar
        self.degree = exponent


class Polynomial(LinkedQueue):

    def __init__(self):
        super().__init__()

    def clear(self):
        while not self.empty():
            self.serve()

    def exp(self):  # 返回最高次项的指数
        if self.empty():
            return -1
        term = self.retrieve()
        return term.degree

    def print_out(self):
        print_node = self._front.next
        first_term = True
        while print_node is not None:
            print_term = print_node.entry
            # 以下if...else语句输出当前项的符号
            if first_term:   # 避免打印首项的'+'号
                first_term = False
                if print_term.coefficient < 0:
                    print("-", end="")
            else:
                if print_term.coefficient < 0:
                    print("-", end="")
                else:
                    print("+", end="")
            # 以下5行语句输出当前项系数的绝对值
            r = print_term.coefficient
            if r < 0:      #  保证r是系数的绝对值
                r = -r
            if r != 1:    #  系数为1，无需输出
                print(r, end="")
            # 以下7行语句输出X^和指数部分，如指数为1或0时需区别处理
            if print_term.degree > 1:
                print("Xˆ", end="")
                print(print_term.degree, end="")
            if print_term.degree == 1:
                print("X", end="")
            if r == 1 and print_term.degree == 0:
                print("1", end="")
            print_node = print_node.next
        print()

    def read(self):
        print("请按指数递减序一行输入一对系数和指数，输入完毕以#结束")
        data = input()
        while data != "#":
            temp = data.split()
            t = Term(float(temp[0]), int(temp[1]))
            self.append(t)
            data = input()

    def copy(self):
        r = Polynomial()
        q = self._front.next
        while q:
            t = Term(q.entry.coefficient, q.entry.degree)
            r.append(t)
            q = q .next
        return r


def add(first, second):
    result = Polynomial()
    while not first.empty() or not second.empty():
        exp1 = first.exp()
        exp2 = second.exp()
        if exp1 == exp2:
            p = first.serve()
            q = second.serve()
            if p.coefficient+q.coefficient != 0:
                t = Term(p.coefficient+q.coefficient, p.degree)
                result.append(t)
        elif exp1 > exp2:
            p = first.serve()
            t = Term(p.coefficient, p.degree)
            result.append(t)
        else:
            q = second.serve()
            t = Term(q.coefficient, q.degree)
            result.append(t)
    return result


def subtract(first, second):
    third = Polynomial()
    while not second.empty():
        q = second.serve()
        t = Term(-q.coefficient, q.degree)
        third.append(t)
    return add(first, third)


def multiply(first, second):
    result = Polynomial()
    while not first.empty():
        t = first.serve()
        third = second.copy()
        temp = mult_term(third, t)
        result = add(result, temp)
    return result


def mult_term(current, t):
    result = Polynomial()
    while not current.empty():
        p = current.serve()
        result.append(Term(p.coefficient * t.coefficient,
                         p.degree + t.degree))
    return result


if __name__ == "__main__":
    a = Polynomial()
    b = Polynomial()
    a.read()
    b.read()
    a.print_out()
    b.print_out()
    ta = a.copy()
    tb = b.copy()
    ma = a.copy()
    mb = b.copy()
    c = add(a, b)
    c.print_out()
    c = subtract(ta, tb)
    c.print_out()
    c = multiply(ma, mb)
    c.print_out()

'''
9 11
-5 8
4 3
1 2
1 1
1 0
#
7 10
5 8
3 2
2 1
-1 0
#

9.0Xˆ11-5.0Xˆ8+4.0Xˆ3+Xˆ2+X+1
7.0Xˆ10+5.0Xˆ8+3.0Xˆ2+2.0X-1
9.0Xˆ11+7.0Xˆ10+4.0Xˆ3+4.0Xˆ2+3.0X
9.0Xˆ11-7.0Xˆ10-10.0Xˆ8+4.0Xˆ3-2.0Xˆ2-X+2.0
63.0Xˆ21+45.0Xˆ19-35.0Xˆ18-25.0Xˆ16+55.0Xˆ13+25.0Xˆ12+18.0Xˆ11-3.0Xˆ10-5.0Xˆ9+10.0Xˆ8+12.0Xˆ5+11.0Xˆ4+Xˆ3+4.0Xˆ2+X-1

1 4
1 2
1 1
#
-5 7
1 6
1 3
#
'''

