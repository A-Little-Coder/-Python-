# 5.6.3 p165
from collections import deque

class Queue:
    def __init__(self):
        self._entry = deque()

    def empty(self):
        return len(self._entry) == 0

    def __len__(self):
        return len(self._entry)

    def append(self, value):
        return self._entry.append(value)

    def serve(self):
        if not self.empty():
            return self._entry.popleft()

    def retrieve(self):
        if not self.empty():
            return self._entry[0]

    def clear(self):
        return self._entry.clear()


if __name__=="__main__":
    sq = Queue()
    for i in range(6):
        sq.append(i)
    print(len(sq))
    print(sq.serve())
    print(sq.serve())
    print(sq.serve())
    print(sq._entry)

    print(sq.retrieve())
    sq.clear()
    print(len(sq))