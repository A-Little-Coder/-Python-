# 5.3.1 p144
class PhysicalModelQueue:

    def __init__(self):
        self._entry = []

    def __len__(self):
        return len(self._entry)

    def empty(self):
        return not self._entry

    def append(self, item):
        self._entry.append(item)

    def serve(self):
        if not self.empty():
            return self._entry.pop(0)
        else:
            return None

    def retrieve(self):
        if not self.empty():
            return self._entry[0]
        else:
            return None

if __name__=="__main__":
    sq = PhysicalModelQueue()
    for i in range(6):
        sq.append(i)
    print(len(sq))
    print(sq.retrieve())
    print(sq.serve())
    print(sq.serve())
    print(sq.serve())
    print(sq.serve())
    print(sq.serve())
    print(len(sq))

'''
6
0
0
1
2
3
4
1
'''