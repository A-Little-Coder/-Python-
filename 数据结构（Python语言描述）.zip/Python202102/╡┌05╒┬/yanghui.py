# 5.5.1 p153-154
from CircularQueue import CircularQueue
from LinkedQueue import LinkedQueue


# def yang_hui(n):
#     line = LinkedQueue()
#     line.append(1)  # 第 1行的 1个数入队
#     for i in range(1, n+1):  # 输出三角形的前 n 行
#         # 第 i 行数据已存放在队列中，输出第i行的全部元素
#         # 同时生成第i+1行的全部i+1个元素并入队
#         s = 0
#         for j in range(1, i + 1): #对于i行j列的元素
#             t = line.serve()  # 出队
#             print("%5d" % t, end="")  # 输出
#             line.append(s + t)  # 生成i+1行j列的元素并入队
#             s = t   # s的值更新为t，用于生成i+1行的下一个元素
#         line.append(1)  # 上面的循环只生成了i+1行的前i个数，最后一个数1入队
#         print()  # 换行


def yang_hui(n):
    line = CircularQueue()		# 也可以用链队列
    line.append(1)				# 第1行的1个数入队
    for i in range(1, n+1):		# 输出杨辉三角形的n行
        # 第i行数据已存放在队列中，在出队并输出第i行的全部元素的同时，
        # 生成第i+1行的全部i+1个元素，并入队
        s = 0
        for j in range(1, i + 1): 		#对于i行j列的元素
            t = line.serve()			# 出队
            print("%5d" % t, end="")  # 输出
            line.append(s + t)		# 生成i+1行j列的元素并入队
            s = t					# s的值更新为t，用于生成i+1行的下一个元素
        line.append(1)				# i+1行的最后一个数1入队
        print()					# 换行


if __name__ == "__main__":
    yang_hui(7)

