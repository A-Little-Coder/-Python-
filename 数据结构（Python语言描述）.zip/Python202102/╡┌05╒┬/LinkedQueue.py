# 5.4 p150-152
from QueueNode import QueueNode


class LinkedQueue:

    def __init__(self):
        self._front = self._rear = QueueNode(None)

    def empty(self):
        return self._front == self._rear

    def __len__(self):
        p = self._front.next
        count = 0
        while p:
            count += 1
            p = p.next
        return count

    def append(self, item):
        new_rear = QueueNode(item)
        self._rear.next = new_rear
        self._rear = new_rear

    def serve(self):
        if self.empty():
            return None
        else:
            old_first = self._front.next
            self._front.next = old_first.next
            item = old_first.entry
            if self._rear == old_first:
                self._rear = self._front
            del old_first
            return item

    def retrieve(self):
        if self.empty():
            return None
        else:
            return self._front.next.entry

    def traverse(self):
        if self.empty():
            print("队列为空")
            return
        else:
            p = self._front.next
            while p is not None:
                print(p.entry, end=' ')
                p = p.next
            print()


if __name__ == "__main__":
    q = LinkedQueue()
    print(q.empty())
    q.append(1)
    q.append(2)
    q.append(3)
    q.append(4)
    t=q.serve()
    print(t)
    t = q.serve()
    print(t)
    q.traverse()
    q.serve()
    q.serve()
    q.traverse()
    print(q.empty())



