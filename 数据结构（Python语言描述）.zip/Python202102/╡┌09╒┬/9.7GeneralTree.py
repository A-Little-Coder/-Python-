# 9.5 树的孩子兄弟链表实现
# 对树 T1 进行测试
from CircularQueue import CircularQueue


class TreeNode:
    def __init__(self, data, first_child=None, next_sibling=None):
        self.data = data
        self.first_child = first_child
        self.next_sibling = next_sibling


class Tree:
    def __init__(self):
        self._root = None

    def postorder(self):
        self.recursive_postorder(self._root)

    def recursive_postorder(self, subroot):
        if subroot:
            self.recursive_postorder(subroot.first_child)
            print(subroot.data, end=" ")
            self.recursive_postorder(subroot.next_sibling)

    def create(self,lst):
        self._root = self.recursive_create(lst)

    def recursive_create(self,lst):
            data = lst.pop(0)
            if data == '#':
                subroot = None
            else:
                subroot = TreeNode(data)
                subroot.first_child = self.recursive_create(lst)
                subroot.next_sibling = self.recursive_create(lst)
            return subroot

    def __len__(self):
        return self.recursive_size(self._root)

    def recursive_size(self, subroot):
        if not subroot:
            return 0
        else:
            return 1 + self.recursive_size(subroot.first_child) + \
                   self.recursive_size(subroot.next_sibling)

    def recursive_height1(self, subroot):
        if not subroot:
            return 0
        maxHeight = 0
        p = subroot.first_child
        while p:
            h = self.recursive_height1(p)
            if h > maxHeight:
                maxHeight = h
            p = p.next_sibling
        return maxHeight + 1

    def recursive_height2(self, subroot):
        if not subroot:
            return 0
        h1 = self.recursive_height2(subroot.first_child)
        h2 = self.recursive_height2(subroot.next_sibling)
        return max(h1+1, h2)

    def height(self):
        return self.recursive_height1(self._root)


if __name__ == "__main__":
    T1 = Tree()
    lst = "A B F # G M # N # # # C H # # D I # J # K # # E L # # # #".split()
    T1.create(lst)  # 通过带#号的先序序列创建树
    print("该树的后序序列为：")
    T1.postorder()
    print("\n该树的结点数为：", len(T1))
    print("该树的高度为：", T1.height())
