from Record import Record
from Node import Node

class ChainHashTable:
    def __init__(self, size):
        self._table = [None for i in range(0, size)]
        self.hash_size = size

    def hash(self, key):
        return key % 7

    def printout(self):
        for i in range(0, self.hash_size):
            print(i, ':', end=" ")
            p = self._table[i]
            while p:
                print(p.entry.key, end="->")  #
                p = p.next
            print()  #

    def insert(self, r):
        i = self.hash(r.key)
        p = self._table[i]
        while p:
            if p.entry == r:
                raise Exception("重复错误")
            p = p.next
        new_node = Node(r)
        new_node.next = self._table[i]
        self._table[i] = new_node
        return True

    def search(self, target):
        i = self.hash(target)
        p = self._table[i]
        while p:
            if p.entry.key == target:
                return p.entry.value
            p = p.next
        return None


if __name__ == "__main__":
    lst = [19, 1, 23, 14, 55, 68, 11, 82, 36]
    table = ChainHashTable(7)
    for v in lst:
        table.insert(Record(v, v))
    table.printout()
    for i in lst:
        print(table.search(i))

