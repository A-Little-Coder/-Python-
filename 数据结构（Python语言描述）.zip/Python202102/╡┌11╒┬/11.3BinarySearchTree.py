from Binary_tree import BinaryTree, BinaryNode
from Record import Record


class BSTree(BinaryTree):
    def __init__(self):
        super().__init__()
        self.comparisons = 0
        
    def print_tree(self):
        lines = self.build_tree_string(self._root)[0]
        a = '\n' + '\n'.join((line.rstrip() for line in lines))
        print(a)

    def build_tree_string(self, root, delimiter='-'):
        if root is None:
            return [], 0, 0, 0
        line1 = []  # 用于存储当前二叉树的根所在行的字符串表示
        line2 = []  # 用于存储当前二叉树根的左右分支所在行的字符串表示
        node_repr = str(root.data.key)
        new_root_width = gap_size = len(node_repr)
        # 递归调用获得左右子树的字符串列表表示、宽度和根的位置信息
        l_box, l_box_width, l_root_start, l_root_end = \
            self.build_tree_string(root.left,  delimiter)
        r_box, r_box_width, r_root_start, r_root_end = \
            self.build_tree_string(root.right, delimiter)
        # 生成当前根结点到左子树的字符串列表部分,在需要的地方用空格填充
        if l_box_width > 0:
            l_root = (l_root_start + l_root_end) // 2 + 1
            line1.append(' ' * (l_root + 1))
            line1.append('_' * (l_box_width - l_root))
            line2.append(' ' * l_root + '/')
            line2.append(' ' * (l_box_width - l_root))
            new_root_start = l_box_width + 1
            gap_size += 1
        else:
            new_root_start = 0
        # 生成当前根结点的列表部分
        line1.append(node_repr)
        line2.append(' ' * new_root_width)
        # 生成当前根结点到左子树的字符串列表部分,在需要的地方用空格填充
        if r_box_width > 0:
            r_root = (r_root_start + r_root_end) // 2
            line1.append('_' * r_root)
            line1.append(' ' * (r_box_width - r_root + 1))
            line2.append(' ' * r_root + '\\')
            line2.append(' ' * (r_box_width - r_root))
            gap_size += 1
        new_root_end = new_root_start + new_root_width - 1
        # 将l_box和r_box与line1和line2的内容进行合并
        gap = ' ' * gap_size
        new_box = [''.join(line1), ''.join(line2)]
        for i in range(max(len(l_box), len(r_box))):
            l_line = l_box[i] if i < len(l_box) else ' ' * l_box_width
            r_line = r_box[i] if i < len(r_box) else ' ' * r_box_width
            new_box.append(l_line + gap + r_line)
        # 返回new_box，宽度和根的位置信息
        return new_box, len(new_box[0]), new_root_start, new_root_end

    def recursive_search_bst(self, sub_root, target):
        if not sub_root:
            return None
        else:
            if sub_root.data.key == target:
                return sub_root
            elif sub_root.data.key < target:
                return self.recursive_search_bst(sub_root.right, target)
            else:
                return self.recursive_search_bst(sub_root.left, target)

    def search(self, target):
        result = self.recursive_search_bst(self._root, target)
        if result:
            return result.data.getValue()
        else:
            return None

    def insert(self, new_data):
        self._root = self.search_and_insert(self._root, new_data)

    def search_and_insert(self, sub_root, new_data):
        if sub_root is None:
            sub_root = BinaryNode(new_data)
            return sub_root
        elif new_data == sub_root.data:
            # print(new_data.key, "结点重复")
            raise Exception("结点重复")
        elif new_data < sub_root.data:
            sub_root.left = self.search_and_insert(sub_root.left, new_data)
        else:
            sub_root.right = self.search_and_insert(sub_root.right, new_data)
        return sub_root

    def remove(self, target):
        self._root = self.search_and_destroy(self._root, target)

    def search_and_destroy(self,sub_root,target):
        if sub_root is None:
            print(target, "对应结点不存在，删除失败")
            return None
        if sub_root.data.key == target:
            return self.remove_root(sub_root)
        elif target < sub_root.data.key:
            sub_root.left = self.search_and_destroy(sub_root.left, target)
        else:
            sub_root.right = self.search_and_destroy(sub_root.right, target)
        return sub_root

    def remove_root(self, sub_root):
        if not sub_root.left and not sub_root.right:
            return None
        elif not sub_root.right:
            return sub_root.left
        elif not sub_root.left:
            return sub_root.right
        else:
            to_delete = sub_root.left
            parent = sub_root
            while to_delete.right:
                parent = to_delete
                to_delete = to_delete.right
            sub_root.data = to_delete.data
            if parent == sub_root:
                sub_root.left = to_delete.left
            else:
                parent.right = to_delete.left
            del to_delete
            return sub_root


if __name__ == "__main__":
    lst = [11, 8, 45, 78, 4, 35, 60] #,78
    bst = BSTree()
    for v in lst:
        bst.insert(Record(v,v))
    bst.print_tree()
    for v in lst:
        print(bst.search(v))
    bst.remove(11)
    bst.print_tree()
    bst.remove(45)
    bst.print_tree()

