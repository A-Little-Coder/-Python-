from Record import Record


class HashTable:
    def __init__(self, size):
        self._table = [None for i in range(0, size)]
        self.hash_size = size

    def hash(self, key):
        return key % 11

    def insert(self, r):
        probe = self.hash(r.key)
        probe_count = 0
        skip = 1
        while self._table[probe] and self._table[probe] != r \
                and probe_count < (self.hash_size + 1) / 2:
            probe_count += 1
            probe = (probe + skip) % self.hash_size
            skip += 2
        if not self._table[probe]:
            self._table[probe] = r
            return True
        elif self._table[probe] == r:
            raise Exception("重复错误")

        else:
            raise Exception("上溢出")

    def search(self, target):
        probe = self.hash(target)
        probe_count = 0
        skip = 1
        while self._table[probe] and self._table[probe].key != target \
                and probe_count < (self.hash_size + 1) / 2:
            probe_count += 1
            probe = (probe + skip) % self.hash_size
            skip += 2
        if not self._table[probe] or probe_count >= (self.hash_size + 1) / 2:
            return None
        else:
            return self._table[probe].value

    def printout(self):
        for i in range(0, self.hash_size):
            if self._table[i]:
                print(i, ':', self._table[i].key)
            else:
                print(i, ':', None)


if __name__ == "__main__":
    lst = [19, 1, 23, 14, 55, 68, 11, 82, 36, 23,10,15,20]  #
    table = HashTable(11)
    for v in lst:
        try:
            table.insert(Record(v,v))
        except Exception as e:
            print(e)
    table.printout()
    for i in lst:
        print(table.search(i))
    print(table.search(40))

