from Record import Record


class OrderedSearchTableList:

    def __init__(self):
        self.data = []

    def __len__(self):
        return len(self.data)

    def empty(self):
        return not self.data

    def remove(self, key):
        r = Record(key)
        self.data.remove(r)

    def insert(self, record):
        pos = self.binarySearchforInsert(record.getKey())[0]
        self.data.insert(pos, record)

    def sequentialSearch(self, target):
        for i in range(len(self.data)):
            current = self.data[i].getKey()
            if current == target:
                return i
            elif current > target:
                return -1
        return -1

    def traverse(self):
        for r in self.data:
            print(r.getKey(), end=" ")

    def binarySearch1(self, target):
        low = 0
        high = len(self.data) - 1
        if low > high:
            return -1
        while low < high:
            mid = (low + high) // 2
            current = self.data[mid].getKey()
            if target <= current:
                high = mid
            else:
                low = mid + 1
        current = self.data[low].getKey()
        if current == target:
            return low
        else:
            return -1

    def recBinarySearch1(self, target, low, high):
        if low > high:
            return -1
        elif low == high:
            current = self.data[low].getKey()
            if current == target:
                return low
            else:
                return -1
        else:
            mid = (low + high) // 2
            current = self.data[mid].getKey()
            if target <= current:
                return self.recBinarySearch1(target, low, mid)
            else:
                return self.recBinarySearch1(target, mid+1, high)

    def callBinarySearch1(self, target):
        return self.recBinarySearch1(target, 0, len(self)-1)

    def binarySearch2(self, target):
        low = 0
        high = len(self.data) - 1
        while low <= high:
            mid = (low + high) // 2
            current = self.data[mid].getKey()
            if target == current:
                return mid
            elif target < current:
                high = mid - 1
            else:
                low = mid + 1
        return -1

    def recBinarySearch2(self, target, low, high):
        if low > high:
            return -1
        else:
            mid = (low + high) // 2
            current = self.data[mid].getKey()
            if target == current:
                return mid
            elif current > target :
                return self.recBinarySearch2(target, low, mid-1)
            else:
                return self.recBinarySearch2(target, mid+1, high)

    def callBinarySearch2(self, target):
       return self.recBinarySearch2(target, 0, len(self)-1)

    def binarySearchforInsert(self, target):
        low = 0
        high = len(self.data) - 1
        while low <= high:
            mid = (low + high) // 2
            current = self.data[mid].getKey()
            if target == current:
                return mid, True
            elif target < current:
                high = mid - 1
            else:
                low = mid + 1
        return low, False


if __name__ == "__main__":
    data = [1, 5, 8, 123, 22, 54, 7, 99, 300, 222]
    table = OrderedSearchTableList()
    for r in data:
        table.insert(Record(r))
    table.traverse()
    print()
    while True:
        target = input("请输入待查找关键字(q退出):")
        if target == 'q':
            break
        target = int(target)
        result = table.binarySearch1(target)
        if result == -1:
            print("在有序顺序表中未找到关键字", target)
        else:
            print("关键字", target, "在有序顺序表中的位置为：",result)
