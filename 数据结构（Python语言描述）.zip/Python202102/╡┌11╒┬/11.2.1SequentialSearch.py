
from Record import Record

class SearchTableList:

    def __init__(self):
        self.data = []

    def __len__(self):
        return len(self.data)

    def empty(self):
        return not self.data

    def insert(self, record):
        self.data.append(record)

    def remove(self, key):
        r = Record(key)
        self.data.remove(r)

    def sequentialSearch(self, target):
        for i in range(len(self.data)):
            if self.data[i].getKey() == target:
                return i
        return -1

    def traverse(self):
        for r in self.data:
            print(r.getKey(), end=" ")


if __name__ == "__main__":
    data = [1, 5, 8, 123, 22, 54, 7, 99, 300, 222]
    table = SearchTableList()
    for r in data:
        table.insert(Record(r))

    while True:
        target = input("请输入待查找关键字(q退出):")
        if target == 'q':
            break
        target = int(target)
        pos = table.sequentialSearch(target)
        if pos == -1:
            print("在静态查找表中未找到关键字", target)
        else:
            print("关键字", target, "在静态查找表中的位置为：",pos)
