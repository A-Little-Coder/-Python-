class BankCard:
    rate = 0.02  # 公有的类变量
    __sequence = 0  # 私有的类变量

    def __init__(self, name, money):
        BankCard.__sequence += 1  # 利用类名访问类变量
        self.bank_id = BankCard.__sequence  # 实例变量
        self.bank_name = name  # 实例变量
        self.bank_amount = money  # 实例变量

    def show(self):
        print('=======================')
        print("卡号:", self.bank_id)
        print("姓名:", self.bank_name)
        print("金额:{:.2f}".format(self.bank_amount))


card1 = BankCard('王老虎', 10000.0)  # 产生对象
card1.show()  # 通过对象调用成员
card2 = BankCard('张大牛', 30000.0)
card2.show()
print(BankCard.rate)
# print(BankCard.__sequence)  # 本句会发生错误，因不可在外部访问类的私有成员


class person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def introduceSelf(self):
        print("{:}说:我{:2d}岁".format(self.name, self.age))

    def getName(self):
        return self.name


class teacher(person):
    def __init__(self, name, age, sub):
        person.__init__(self, name, age)  # 调用父类的函数
        self.subject = sub

    # 覆盖父类的方法
    def introduceSelf(self):
        print("{:}说:我{:2d}岁,我教{:}".format(self.name, self.age, self.subject))


per1 = person('Tom', 20)
per1.introduceSelf()

sir1 = teacher("Jerry", 40, "Programing")
sir1.introduceSelf()
print(sir1.getName())

class prime:
    def __init__(self, n):
        self.cur = 1
        self.top = n

    def __iter__(self):
        return self

    def isPrime(self, num):
        if num <= 1:
            return False
        from math import sqrt
        upperNumber = int(sqrt(num))
        for i in range(2, upperNumber + 1):
            if num % i == 0:
                return False
        return True

    def __next__(self):
        for i in range(self.cur+1, self.top + 1):
            if self.isPrime(i) == True:
                self.cur = i
                return i
        raise StopIteration

pri = prime(50)
for i in pri:			#在迭代器中迭代
    print(i, end=" ")
print()

def prime():
    def isPrime( num):
        if num <= 1:
            return False
        from math import sqrt
        upperNumber = int(sqrt(num))
        for i in range(2, upperNumber + 1):
            if num % i == 0:
                return False
        return True

    cur=2
    while True:
        if isPrime(cur)==True:
            yield cur
        cur+=1

pri=prime()
for i in range(20):
    print(next(pri),end=" ")
