num = 5		#直接赋值，解释器自动推导类型
print(type(num))
num = 5.8 	#通过赋值，改变变量的类型
print(type(num))

print(0.1 * 26)			#0.1乘以26
print(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1)	 #26个0.1连加

print("C:\\Users\\Public\\Downloads")
print(r"C:\Users\Public\Downloads")

str1="Soochow"
print(str1[2 : 4 : 1])		#对第2个和第3个字符切片
print(str1[2 : 4 :])		#对第2个和第3个字符切片
print(str1[: : 2])		#从头到尾，每隔一个字符切片
print(str1[: : -1])		#通过切片得到字符串的逆序串

print('Soochow' + " University")  #字符串连接
print("dog" * 3)               #字符串重复3次
print(ord('A'))                #得到A的内码
print(chr(97))                #得到97作为内码所对应的字符

lst1=[]				#空列表
print(lst1)
lst2=[1, 2, 3]			#列表初始化
print(lst2)
lst3=[1, 'abc', [3, 4]]	#元素类型不同的列表
print(lst3)
lst4=list("hello")		#将字符串转换为列表
print(lst4)

lst=[1, 2, 3, 4, 5, 6, 7, 8, 9]
lst[: : 2]=[0]*len(lst[: : 2])
lst[1: : 2]=[1]*len(lst[1: : 2])
print(lst)

lst=[1, 3, 5]
lst.append([2, 7])
print(lst)

lst=[1, 3, 5]
lst.extend([2, 7])
print(lst)

lst1=[1, 3, 5]
lst2=lst1
lst2[2]=7
print(lst1)

lst1=[1, 3, 5]
lst2=lst1.copy()
lst2[2]=7
print(lst1)

tup1=()                	#空元组
tup2=(3,)               	#一个元素的元组
tup3=("湖北", "浙江")    	#多个元素的元组
lst=['武汉', '孝感', '黄冈']
tups=tuple(lst)         	#从列表得到元组

dict1={}    							#空字典
dict2=dict() 							#空字典
dict3={'壹':1, '贰':2, '叄':3} 				#显式定义字典
dict4=dict((['dog', '狗'], ['cat', '猫']))		#基于元组定义字典
print(dict4['dog'])  					#通过key作为索引访问字典的元素


words={"星期一" : "monday",
       "星期二" : "tuesday",
       "星期三" : "wednesday",
       "星期四" : "thursday",
       "星期五" : "friday",
       "星期六" : "saturday",
       "星期天" : "sunday"}
word=input("请输入中文")
print(words.get(word, "查无此词"))


lst1 = [1, 2]
lst2 = [1, 2]
print(lst1 == lst2)	#此行会输出True
print(lst1 is lst2)	#此行会输出False


def isPrime(num):
    '''
    本函数用于判断一个正整数是不是素数
    :param  num:		待判断的正整数
    :return: 			True-是素数
             		Fasle-不是素数
             		None-参数不合法
    '''
    if isinstance(num, int) == False:
        return None
    if num <= 0:
        return None
    if num == 1:
        return False
    import math
    maxNumber = int(math.sqrt(num))
    for i in range(2, maxNumber + 1):
        if num % i ==0 :
            return False
    return True

def calc(marks):
    maxVal = max(marks)
    minVal = min(marks)
    return maxVal, minVal, (sum(marks) - maxVal - minVal) / (len(marks) - 2)


maxMark, minMark, averMark = calc([88, 65, 78, 99, 45, 72])
print('最高分：', maxMark)
print('最低分：', minMark)
print('平均分：', averMark)

def exchange(num1, num2):
    num1, num2 = num2, num1
    print(num1, num2)		# 输出交换后的值

num1 = 5
num2 = 7
print(num1, num2)			#输出调用前的值
exchange(num1, num2)		#试图交换
print(num1, num2)			#输出调用后的值

def change(lst, dict1):
    lst[0] = 2
    dict1['one'] = "一"

lst = [1, 2, 3]
dict1 = {'one':1}
change(lst, dict1)
print(lst)
print(dict1)


def change(lst):
    lst=list(set(lst)) 	# 试图利用集合去重再转回列表
    print(lst)

lst=[1, 2, 3, 2, 3]
change(lst)
print(lst)

def example(num1, num2):
    print("num1=", num1, "num2=", num2)

example(20, 10)
example(num2 = 10, num1 = 20)

str1=input("请输入一个字符串")			# 获取字符串输入则无须转换
print(str1)
num=int(input("请输入一个整数"))		# 获取整数可以int强制转换
print(num)
nums=list(map(int, input("请输入多个整数用空格分开").split()))  # 获取多个整数到列表
print(nums)


def copyFile(src, des):
    srcFp=open(src, "r")
    desFp=open(des, "w")

    ch=srcFp.read(1)
    while ch != "":
        desFp.write(ch)
        ch=srcFp.read(1)

    srcFp.close()
    desFp.close()


def getLen(filename):
    with open(filename, "r") as file:
        file.seek(0, 2)     	# 定位文件指针到文件的最后
        return file.tell()  		# 返回文件指针所在的位置

import urllib.request
from bs4 import BeautifulSoup   		# 导入用于解析网页

def getAurlHtmlAndParse(url):
    htm = urllib.request.urlopen(url)    	# 获取网页
    soup = BeautifulSoup(htm.read().decode('utf-8'), 'html.parser')
    return soup

def delScriptAndStyleFromHtml(soup):
    for script in soup(["script", "style"]):
        script.extract()    				# 过滤脚本和样式
    text = soup.get_text()
    lines = [line.strip() for line in text.splitlines()]
    chunks = [phrase.strip() for line in lines for phrase in line.split(" ")]
    text = ' '.join(chunk for chunk in chunks if chunk)
    text = text.replace(" ", "")
    return text

def GetTextFromUrl(url):
    soup = getAurlHtmlAndParse(url)			# 获取网页
    text = delScriptAndStyleFromHtml(soup)  	# 去除脚本和样式
    return text


if __name__ == "__main__":
    print(GetTextFromUrl("http://www.suda.edu.cn/"))
