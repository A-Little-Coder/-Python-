import abc


class animal(metaclass=abc.ABCMeta):  # 抽象类
    @abc.abstractmethod
    def sound(self):  # 抽象方法
        pass


class dog(animal):
    def sound(self):  # 给出具体实现
        print("汪汪汪")


class cat(animal):
    def sound(self):  # 给出具体实现
        print("喵喵喵")


class duck(animal):
    def sound(self):  # 给出具体实现
        print("嘎嘎嘎")


def playSound(temp):  # 本函数代码无须修改可以调用animal各种派生类的sound()方法
    temp.sound()


dog1 = dog()
cat1 = cat()
duck1 = duck()

playSound(dog1)
playSound(cat1)
playSound(duck1)
