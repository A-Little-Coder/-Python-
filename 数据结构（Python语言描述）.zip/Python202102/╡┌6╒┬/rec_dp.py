# p199 带备忘录斐波那契数列
def fib_memo(n, result):
    if n == 0 or n == 1:
        result[n] = 1
        return 1
    elif result[n] > 0:
        return result[n]
    result[n] = fib_memo(n-1, result) + fib_memo(n-2, result)
    return result[n]

result=[0 for i in range(9)]
fib_memo(8,result)
print(result)

# p200 动态规划求连续子序列之和
def max_sum(lst):
    m = [0] * len(lst)
    m[0] = max(lst[0], 0)
    for i in range(1, len(lst)):
            m[i] = max(m[i-1] + lst[i], 0)
    return max(m)

# p201 动态规划求连续子序列之和 改进
def max_sum2(lst):
    maxsum = sum =max(lst[0], 0)
    for i in range(1, len(lst)):
        sum = max(sum + lst[i], 0)
        if sum > maxsum:
            maxsum = sum
    return maxsum


lst1 = [-2.5, 4, 0, -3, 2, 8, -1]
print(max_sum(lst1))
print(max_sum2(lst1))
lst2 = [-2, 11, -4, 13, -5, 2]
print(max_sum(lst2))
print(max_sum2(lst2))

