# 6.5 p196-201
def exhaustive(valueList,change):
    lst = []
    for a in range(change // valueList[0] + 1):
        for b in range((change-a*valueList[0])//valueList[1] + 1):
            for c in range((change-a*valueList[0]-b*valueList[1])
                           //valueList[2] + 1):
                remain = change - a*valueList[0] - b*valueList[1]\
                             - c*valueList[2]
                if remain % valueList[3] == 0:
                    d = remain // valueList[3]
                    lst.append(a+b+c+d)
    return min(lst)


def greedy(valueList, change):
    numchange = 0
    for i in range(len(valueList)-1,-1,-1):
        numchange += change // valueList[i]
        change %= valueList[i]
    return numchange


def rec_mc(valueList, change):  # 递归求解，效率差
    global count
    count += 1
    if change in valueList:
        return 1
    else:
        minchange = change
        for i in [c for c in valueList if c <= change]:
            numchange = 1 + rec_mc(valueList, change - i)
            if numchange < minchange:
                minchange = numchange
        return minchange


def rec_mc_memo(valueList, change, knownResults ):
    # 递归，带备忘录
    global count
    count += 1
    minchange = change
    if change in valueList:  # 递归基本结束条件
        knownResults[change] = 1  # 记录最优解
        return 1
    elif knownResults[change] > 0:
        return knownResults[change]  # 查表成功，直接用最优解
    else:
        for i in [c for c in valueList if c <= change]:
            numchange = 1 + rec_mc_memo(valueList, change - i, knownResults )
            if numchange < minchange:
                minchange = numchange
        knownResults[change] = minchange  # 找到最优解，记录到表中
        return minchange


def dpMakeChange(valueList, change, minchange):   # 动态规划
    for amount in range(change+1):
        changeCount = amount
        #  初始化一个最大值
        # 对当前change，依次减去每种货币面额，
        # 查表计算并得到最小找零数changeCount，记录在minchange中
        for j in [c for c in valueList if c <= amount]:
            if minchange[amount - j] + 1 < changeCount:
                changeCount = minchange[amount - j] + 1
        minchange[amount] = changeCount
    return minchange[change]


def dpMakeChange2(valueList, change, minchange, changeUsed):  # 动态规划，功能扩展版
    for cents in range(change+1):
        coinCount = cents
        #  初始化一个最大值
        newcoin = 1 # 新加的硬币面值
        # 对当前cents，依次减去每个硬币，查表获得最少硬币数，并记录其最少硬币数
        for j in [c for c in valueList if c <= cents]:
            if minchange[cents - j] + 1 < coinCount:
                coinCount = minchange[cents - j] + 1
                newcoin = j
        minchange[cents] = coinCount
        changeUsed[cents] = newcoin  # 记录增加的硬币面值
    return minchange[change]


def printchange(minchange, coinUsed, change):
    coin = change
    while coin > 0:
        thisCoin = coinUsed[coin]
        print(thisCoin)
        coin -= thisCoin
#
# clist = [1,5,10,21,25]
# amnt = 24
# change = [0] * (amnt+1)
# changeUsed = [0] * (amnt + 1)
# print(dpMakeChange2(clist, amnt, change,changeUsed))
# print(change)
# print(changeUsed)
# printchange(change,changeUsed,amnt)


import time
if __name__ == "__main__":
    clist = [1, 5, 10,21,25]
    amnt = 24
    # start = time.perf_counter()
    # print("穷举算法", amnt, "元兑换最少找零张数:", end=" ")
    # print(exhaustive(clist, amnt))
    # end = time.perf_counter()
    # print("所花时间%f" % (end - start))

    # start = time.perf_counter()
    # print("贪心算法", amnt, "元兑换最少找零张数:", end=" ")
    # print(greedy(clist, amnt))
    # end = time.perf_counter()
    # print("所花时间%f" % (end - start))
    #
    # count = 0
    # start = time.perf_counter()
    # print("递归分治法", amnt, "元兑换最少找零张数:", end=" ")
    # print(rec_mc(clist, amnt))
    # end = time.perf_counter()
    # print("所花时间%f" % (end - start))
    # print(count)
    #
    # count = 0
    # start = time.perf_counter()
    # print("递归带备忘录法", amnt, "元兑换最少找零张数:", end=" ")
    # lst=[0]*(amnt+1)
    # print(rec_mc_memo(clist,amnt, lst))
    # end = time.perf_counter()
    # print("所花时间:",end - start)
    # print(count)
    # print(lst)
    #
    # start = time.perf_counter()
    # print("动态规划法", amnt, "元兑换最少找零张数:", end=" ")
    # lst = [0]*(amnt+1)
    # print(dpMakeChange(clist, amnt, lst))
    # end = time.perf_counter()
    # print("所花时间:", end - start)
    # print(lst)

    coins = [0] * (amnt+1)
    coinsUsed = [0] * (amnt + 1)
    print(dpMakeChange2(clist, amnt, coins,coinsUsed))
    print(coins)
    print(coinsUsed)
    printchange(coins,coinsUsed,amnt)

