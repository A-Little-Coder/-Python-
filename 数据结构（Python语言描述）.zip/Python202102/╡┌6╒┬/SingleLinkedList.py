#  p 6.2.2 p 178-179  例6.9-6.13 单链表下的递归算法
# 例6.18 递归消除

from ArrayStack import ArrayStack
from AbstractList import AbstractList
from Node import Node
class LinkedList(AbstractList):
    def get_head(self):
        return self._head

    def __init__(self):
        super().__init__()
        self._head = Node(None)

    def empty(self):
        return self._head.next is None

    def clear(self):
        p = self._head.next
        self._head.next = None
        while p:
            q = p
            p = p.next
            del q


    def remove(self, i):
        if i < 0:
            raise IndexError("i is too small")
        previous = self._head
        j = -1
        while previous and j < i - 1:
            previous = previous.next
            j += 1
        if previous is None:
            raise IndexError("k is too big,no element has position k-1")
        current = previous.next
        if current is None:
            raise IndexError("k is too big,no element has position k")
        previous.next = current.next
        item = current.entry
        del current
        return item

    def retrieve(self, i):
        if i < 0:
            raise IndexError("i is too small")
        p = self._head.next
        count = 0
        while p and count < i:
            p = p.next
            count += 1
        if p:
            return p.entry
        else:
            raise IndexError("i is too big")

    def replace(self, i, item):
        if i < 0:
            raise IndexError("i is too small")
        p = self._head.next
        j = 0
        while p is not None and j < i:
            p = p.next
            j += 1
        if p != None:
            p.entry = item
        else:
            raise IndexError("i is too big")

    def contains(self, item):
        p = self._head.next
        while p is not  None:
            if p.entry == item:
                return True
            p = p.next
        return False

    def traverse(self):
        p = self._head.next
        while (p != None):
            print(p.entry, end=" ")  #
            p = p.next
        print()  #

    def __iter__(self):
        p = self._head.next
        while (p != None):
            yield p.entry
            p = p.next

    def recursive_len(self, first):
        if not first:
            return 0
        else:
            return 1 + self.recursive_len(first.next)

    def __len__(self):
        return self.recursive_len(self._head.next)


    def recursive_reverse_traverse(self, first):  # 例6.9
        if first:
            self.recursive_reverse_traverse(first.next)
            print(first.entry, end=" ")

    def reverse_traverse(self):
        self.recursive_reverse_traverse(self._head.next)

    def reverse_traverse(self):  # 例6.18
        p = self._head.next
        st = ArrayStack()
        while p:
            st.push(p.entry)
            p = p.next
        while not st.empty():
            print(st.pop(), end=" ")
        print()

    def recursive_removeall(self, first, item):  # 例6.10
        # 递归算法，删除以first为首结点的单链表中所有值为item的结点
        # 返回形成的新链表的首结点指针
        if not first:
            return None
        if first.entry == item:
            return self.recursive_removeall(first.next, item)
        else:
            p = self.recursive_removeall(first.next, item)
            first.next = p
            return first

    def removeall(self, item):
        self._head.next = self.recursive_removeall(self._head.next, item)

    def recursive_reverse(self, first):  # # 例6.11 递归逆置
        if not first or not first.next:
            return first
        p = first.next
        new_head = self.recursive_reverse(p)
        p.next = first
        first.next = None
        return new_head

    def reverse(self):
        self._head.next = self.recursive_reverse(self._head.next)

    def recursive_insert(self, first, i, x):  # 例6.12
        if i < 0:
            raise IndexError(" i太小")
        if not first and i > 0:
            raise IndexError(" i太大")
        if i == 0:
            new_node = Node(x, first)
            return new_node
        else:
            first.next = self.recursive_insert(first.next, i-1, x)
            return first

    def insert(self, i, x):
        self._head.next = self.recursive_insert(self._head.next, i, x)

    def recursive_split(self, first):  # 例6.13
        if first is None or first.next is None:
            return None
        second = first.next
        first.next = second.next
        second.next = self.recursive_split(second.next)
        return second

    def split(self):
        oddList = LinkedList()
        oddList.get_head().next = self.recursive_split(self._head.next)
        return oddList


if __name__ == "__main__":
    lst2 = LinkedList()
    lst2.insert(0, 0)
    lst2.insert(1, -1)
    lst2.insert(2, 3)
    lst2.insert(3, -4)
    lst2.insert(4, 1)
    lst2.traverse()
    lst2.reverse()
    lst2.traverse()


