# 6.1.2 例6.5 p175
import turtle


def tree(branch_len, t):    # 例6.5
    t.pendown()					    # 画笔放下
    t.forward(branch_len)			# 绘制长度为branch_len的树枝
    t.penup()						# 画笔抬起
    if branch_len > 10:				# 如果branch_len大于10
        t.left(20)					# 调整画笔方向往左偏20度
        tree(branch_len - 10, t)			# 绘制树干长度为branch_len-10的分形树
        t.right(40) 				# 调整画笔方向往右偏20度
        tree(branch_len - 10, t)			# 绘制树干长度为branch_len-10的分形树
        t.left(20)					# 画笔方向归位
    t.backward(branch_len)			# 回到起点


def main():
    t = turtle.Turtle()
    myWin = turtle.Screen()
    t.left(90)                  # 使小乌龟画笔方向往上
    t.color("green")
    tree(75, t)             # 绘制树干长度为75的分形树
    myWin.exitonclick()


main()
