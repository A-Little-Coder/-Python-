#  p 6.1 p 174-175  例6.1-例6.4
# hanoi塔 例6.14  例6.17

def fact(n):  # 例6.1
    if n == 0:
        return 1
    else:
        return n*fact(n-1)


print(fact(8))


def gcd(m, n):  # 例6.2
    r = m % n
    if r == 0:
        return n
    else:
        return gcd(n, r)


print(gcd(64, 56))


def fibonacci(n): # 例6.3,6.16
    if n == 0 or n == 1:
        return 1
    else:
        return fibonacci(n-1)+fibonacci(n-2)


print(fibonacci(8))


def catalan(n):  # 例6.4
    if n == 0 or n == 1:
        return 1
    else:
        result = 0
        for i in range(n):
            result += catalan(i) * catalan(n-i-1)
        return result


print("cata",catalan(5))


def catalan(n):
    s = fact(2*n)
    t = fact(n+1)*fact(n)
    print(s//t)


catalan(5)


def hanoi(count, start, finish, temp):  # 例6.14
    if count == 1:
        print("move disk 1 from", start, "to", finish)
        return
    hanoi(count-1, start, temp, finish)
    print("move disk", count, "from", start, "to", finish)
    hanoi(count-1, temp, finish, start)


hanoi(3, 'A', 'C', 'B')
print("#################")


def hanoi(count, start, finish, temp):  # 例6.17
    while count > 1:
        hanoi(count-1, start, temp, finish)  # 非尾递归，保留
        print("Move disk", count, "from", start, " to ", finish)
        count -= 1
        start, temp = temp, start
    print("move disk 1 from", start,  " to ", finish)


hanoi(3, 'A', 'C', 'B')
print("#################")

