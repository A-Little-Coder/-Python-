# 6.3.3 p186-187
def group(inList, k, comboList):
    """从inList表中取k个数，添加到comboList的末尾"""
    if k == 0:
        print(comboList)
    elif len(inList) > 0:
        first = inList[0]			# first为inList中第一个元素
        remain = inList[1:]			# remain为除第一个元素外其余元素构成的新表
        comboList.append(first)		# comboList中包含第一个元素
        group(remain, k-1, comboList)  # 在remain中取k-1个数添加到comboList尾部
        comboList.pop()				# comboList中不包含第一个元素
        group(remain, k, comboList)  # 在remain中取k个数，添加到comboList尾部


'''从长度为n的inList数组的index下标位置开始，求k个组合数，结果放在tmpList中,找到一组则输出。
如果k=0，输出tmpList；
如果k>1，对于[index,n-k+1)范围的每一个i，取inList[i]作为第1个元素，在i位置之后的表中再找出k-1个数即可。
（i的左边界index(取得到)，i位置之后的表长度至少需要k-1，所以i的右边界是n-k+1（取不到）。）


'''
def combine(index,inList,tmplist, k,n):
    # 从长度为n的inList表中的第index位置开始 取k个数，添加到tmpList的末尾
    if k == 0:
        print(tmplist)
    else:
        for i in range(index, n-k+1):   # 这里n-k+1简化成n也可以
            tmplist.append(inList[i])  # 取i号元素作为第1个元素
            combine(i + 1, inList, tmplist, k - 1, n)  # 在i+1位置开始的表中找出k-1个数
            tmplist.pop()



n = 5
m = 3

lst = [i for i in range(1,n+1)]
tmp = []

group(lst, m, tmp)

print("#################################")

combine(0, lst, tmp, m, len(lst))
