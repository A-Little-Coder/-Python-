# Python列表下递归算法 例6.2.2 例6.6
def recursive_count1(alst, x):  # 例6.6
    if len(alst) == 0:
        return 0
    else:
        result = recursive_count1(alst[0:-1], x)
        if alst[-1] == x:
            result += 1
        return result


def recursive_count(alst, n, x):
    if n == 0:
        return 0
    else:
        result = recursive_count(alst, n-1, x)
        if alst[n-1] == x:
            result += 1
        return result


alist = [1,2,1,6,1,7,1]
print(recursive_count(alist,7,1))