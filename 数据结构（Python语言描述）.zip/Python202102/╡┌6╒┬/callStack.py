# 6.4.1 p187
def A(a, b):
    i = 3
    a = B(i)  # addr2位置
    return a+b


def B(d):
    x = 2
    y = 3
    return d+x+y


if __name__ == "__main__":  # 开始运行位置
    m = 0
    n = 1
    print(A(m, n))   # addr1位置
