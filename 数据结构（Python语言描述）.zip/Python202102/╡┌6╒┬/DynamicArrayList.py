#  p 6.2.2 p 178-179  例6.7 例6.8 C动态数组实现顺序表下的递归算法

import ctypes  # 提供底层数组
from AbstractList import AbstractList

class DynamicArrayList(AbstractList):
    def __init__(self,cap=0):
        """初始化一个空表"""
        super().__init__()
        self._cur_len = 0  # 线性表元素个数计数
        self._capacity = cap  # 默认数组容量
        self._entry = self._make_array(self._capacity)  # 存放所有表元素的数组

    def empty(self):
        return self._cur_len == 0

    def __len__(self):
        """返回线性表中元素个数"""
        return self._cur_len

    def clear(self):
        del self._entry
        self._capacity = 0
        self._cur_len = 0


    def insert(self, i, item):
        """将元素item插入到表的i号位置"""
        if not 0 <= i <= self._cur_len:
            raise IndexError("插入位置不合法")
        if self._cur_len == self._capacity:  # 如果线性表的空间已用完
            if self._capacity == 0:
                cap = 4
            else:
                cap = 2 * self._capacity
            self._resize(cap)  # 给线性表扩容1倍空间
        for j in range(self._cur_len, i, -1):  # 线性表尾部至k号位置所有元素后移
            self._entry[j] = self._entry[j - 1]
        self._entry[i] = item  # 将新元素item放在i号位置
        self._cur_len += 1  # 表长增1

    def remove(self, i):
        if not 0 <= i < self._cur_len:
            raise IndexError("删除位置不合法")
        item = self._entry[i]
        for j in range(i, self._cur_len - 1):  # 将找到位置之后的元素后移。
            self._entry[j] = self._entry[j + 1]
        self._cur_len -= 1  # 表长减1
        return item  # 返回被删除元素

    def retrieve(self, i):
        if not 0 <= i < self._cur_len:
            raise IndexError("读取位置不合法")
        return self._entry[i]

    def replace(self, i, item):
        if not 0 <= i < self._cur_len:
            raise IndexError("写入位置不合法")
        self._entry[i] = item

    def contains(self, item):
        for i in range(self._cur_len):
            if self._entry[i] == item:
                return True
        return False

    def traverse(self):
        for i in range(self._cur_len):
            print(self._entry[i],end=" ")
        print()

    def _make_array(self, c):  # 私有方法
        """返回一个容量为c的数组"""
        # return (c * ctypes.c_long)()
        return (c * ctypes.py_object)()

    def __str__(self):
        """将线性表转换成字符串，用于输出线性表所有元素"""
        elements = ' '.join(str(self._entry[c]) for c in range(self._cur_len))
        return elements

    def append(self, item):
        """将元素item添加到线性表尾部"""
        if self._cur_len == self._capacity:  # 如果线性表的空间已用完
            if self._capacity == 0:
                cap = 4
            else:
                cap = 2 * self._capacity
            self._resize(cap)  # 给线性表扩容1倍空间
        self._entry[self._cur_len] = item   # 将item存储到表尾位置
        self._cur_len += 1   # 表长增1

    def __iter__(self):
        for i in range(self._cur_len):
            yield self._entry[i]

    def _resize(self, c):  # 私有方法
        """将数组空间扩容至c."""
        temp = self._make_array(c)  # 生成新的更大的数组temp
        for k in range(self._cur_len):  # 将原线性表元素复制到新数组temp中
            temp[k] = self._entry[k]
        self._entry = temp  # 启用新数组temp存放线性表元素
        self._capacity = c  # 当前线性表的容量为c

    def remove_by_value(self, item):
        """删除值为item的元素在线性表中的第一次出现，如果不存在，则抛出ValueError异常"""
        for k in range(self._cur_len):
            if self._entry[k] == item:  # 找到元素item
                for j in range(k, self._cur_len - 1):  # 将找到位置之后的元素后移。
                    self._entry[j] = self._entry[j + 1]
                self._entry[self._cur_len - 1] = None
                self._cur_len -= 1  # 表长减1
                return  # 直接退出
        raise ValueError('value not found')  #未找到item值

    def _recursive_count(self, entry, n, x):
        if n == 0:
            return 0
        else:
            result = self._recursive_count(entry, n - 1, x)
            if entry[n - 1] == x:
                result += 1
            return result

    def count(self, x):
        return self._recursive_count(self._entry, len(self), x)

    def recursive_average(self, n):  # 例6.7
        if n == 0:
            return 0
        average = self.recursive_average(n - 1)
        return (average * (n - 1) + self._entry[n - 1]) / n

    def average(self):
        return self.recursive_average(self._cur_len)

    def recur_is_pali(self, start, end):   # 例6.8
        if start >= end:								# 空表或长度为1
            return  True
        else:
            if self._entry[start] != self._entry[end]:		# 首尾元素不同，返回False
                return False
            else:								# 对除首尾元素之外的部分进行判断
                return self.recur_is_pali(start+1, end-1)

    def is_pali(self):
        return self.recur_is_pali(0, self._cur_len-1)


if __name__ == "__main__":
    a = DynamicArrayList()
    a.insert(0, 1)
    a.insert(1, 2)
    a.insert(2, 3)
    a.insert(3, 4)
    a.insert(4, 3)
    a.insert(5, 2)
    a.insert(6, 1)
    print(a)
    print(a.count(1))
    a.traverse()
    print(a.average())
    print(a.is_pali())




