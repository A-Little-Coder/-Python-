# 6.3.1 p184-185
from ArrayStack import  ArrayStack


class Queens:

    def __init__(self,size):
        self.board_size = size
        self.queen_square = [[False for i in range(0, size)] for j in range(0, size)]

    # 判别棋盘中是否已有n个皇后
    def is_solved(self, count):
        return count == self.board_size

    # 输出打印n皇后棋盘
    def print(self):
        for i in range(self.board_size):
            for j in range(self.board_size):
                if self.queen_square[i][j] == 1:
                    print("●", end=" ")
                else:
                    print("□", end=" ")
            print()
        print("#################")

    # 如果count行col列没有皇后站岗，返回True
    def unguarded(self, count, col):
        ok = True
        i = 0
        while i < count and ok:
            ok = not self.queen_square[i][col]
            i += 1
        i = 1
        while ok and count - i >= 0 and col - i >= 0:
            ok = not self.queen_square[count - i][col - i]
            i += 1
        i = 1
        while ok and count - i >= 0 and col + i < self.board_size:
            ok = not self.queen_square[count - i][col + i]
            i += 1
        return ok

    # 将皇后放入位置(count,col)
    def insert(self, count, col):
        self.queen_square[count][col] = True

    # 将皇后从位置(count,col)移掉
    def remove(self, count, col):
        self.queen_square[count][col] = False

    # 利用栈回溯
    def solve(self):
        st = ArrayStack()
        count = 0
        nxt_col = 0
        while True:
            for col in range(nxt_col, self.board_size):
                if self.unguarded(count, col):
                    self.insert(count, col)
                    st.push((count, col))
                    count += 1
                    nxt_col = 0
                    if self.is_solved(count):
                        self.print()
                        # count, nxt_col = st.pop()
                        # self.remove(count, nxt_col)
                        # nxt_col += 1
                    break

            else:
                if not st.empty():
                    count, nxt_col = st.pop()
                    self.remove(count, nxt_col)
                    nxt_col += 1
                else:
                    break  # 已无解

    def solve1(self):
        self.solve_from(0)

    # 利用递归回溯

    def solve_from(self, count):
        # global jishu
        # global  number
        # jishu = jishu +1
        if self.is_solved(count):
            # number += 1
            self.print()
        else:
            for col in range(self.board_size):
                if self.unguarded(count, col):
                    self.insert(count, col)
                    self.solve_from(count + 1)
                    self.remove(count, col)

import time
jishu = 0
number = 0
cf = Queens(6)

start =time.perf_counter()
cf.solve1()
end = time.perf_counter()
a = end-start
print("########################################")

start =time.perf_counter()
cf.solve()
end = time.perf_counter()
b = end-start

print(a,b)



