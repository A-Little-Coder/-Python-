# 3.6.2 p95
from Node import Node


class CircularLinkedList:

    def __init__(self):
        self._head = None

    def create_cll(self, n):
        self._head = p = n_node = Node(1)
        for i in range(2, n+1):
            n_node = Node(i)
            p.next = n_node
            p = p.next
        n_node.next = self._head

    def josephus(self, n, m):
        self.create_cll(n)  # 创建单向循环链表
        p = self._head  # p定位在不带头结点的循环链表的首结点
        q = p
        count = n  # count是表的长度
        while q.next != p:
            q = q.next  # q定位在该链表的末尾，即q.next是p结点
        while count != 0:
            num = m % count
            # 如果报的数很大，为减少循环，将报数的范围缩小到小于count
            if num == 0:
                num = count  # 如果num为0，说明报的数应为count
            while num > 1:  # 循环报数
                q = q.next
                p = p.next
                num -= 1
            print(p.entry, end="")  # 输出将要删除结点的值
            if count > 1:
                print(",", end="")
            q.next = p.next
            del p  # 删除p结点
            count -= 1
            p = q.next  # 恢复p的位置，继续进行下一轮报数
        print()


def josephus_L(n, m):  # p95
    people = list(range(1, n+1))
    i = 0
    for num in range(n, 0, -1):
        i = (i + m-1) % num
        print(people.pop(i), end="")
        if num > 1:
            print(",", end="")

if __name__ == '__main__':
    csl = CircularLinkedList()
    csl.josephus(10, 3)
    josephus_L(10, 3)






