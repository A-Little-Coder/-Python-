# 3.7.2 p100
from Node import Node
from LinkedList import LinkedList


class OrderedLinkedList(LinkedList):
    def add(self, item):
        p = self._head
        while p.next and p.next.entry <= item:
            p = p.next
        newnode = Node(item, p.next)
        p.next = newnode

    def insert(self, position, item):
        if position < 0 or position > len(self):
            raise Exception("插入位置不合法")
        if position > 0:
            previous = self.retrieve(position - 1)
            if item < previous:
                raise Exception("插入位置不正确")
        if position < len(self) - 1:
            nextvalue = self.retrieve(position)
            if item > nextvalue:
                raise Exception("插入位置不正确")
        super().insert(position, item)

    def replace_by_position(self, position, item):
        pass



'''将A和B和交集结果C组织为有序表
A=（1，2，7）
B=（2，3，5，6，7)
则：C=A∩B={2，7}
求交集的算法：用双游标法，即设两个变量分别指示A和B的当前位置，设为 i和j，初始分别为0。
将Ai与Bj进行比较，
Ai<Bj，说明Ai不在C中，i++
Ai=Bj，加入到c中，i+，j++
否则，说明Bj不在C中，j++
通过一次比较，可以加入或排除一个元素。元素总数最多为m+n，因此最多比较次数最多为m+n，算法的时间复杂度可以达到O(m+n)。
'''

def intersect(la, lb):  # p94
    m = len(la)
    n = len(lb)
    lc = OrderedLinkedList()
    i = 0
    j = 0
    k = 0
    while i < m and j < n:
        item_a = la.retrieve(i)
        item_b = lb.retrieve(j)
        if item_a < item_b:
            i += 1
        elif item_a > item_b:
            j += 1
        else:
            lc.insert(k, item_a)
            k += 1
            i += 1
            j += 1
    return lc


def intersect2(alist, blist):
    c = OrderedLinkedList()
    p = alist.get_head().next
    q = blist.get_head().next
    c = LinkedList()
    r = c.get_head()
    while p and q:
        if p.entry == q.entry:
            cnode = Node(p.entry)
            r.next = cnode
            r = cnode
            p = p.next
            q = q.next
        elif p.entry < q.entry:
            p = p.next
        else:
            q = q.next
    return c

if __name__ == "__main__":
    alst = OrderedLinkedList()
    lst1 = [2, 1, 3, 6, 9, 7, 6, 10]
    blst = OrderedLinkedList()
    lst2 = [2, 9, 1, -8]
    for v in lst1:
        alst.add(v)
    for v in lst2:
        blst.add(v)
    alst.traverse()
    blst.traverse()
    clist = intersect(alst,blst)
    clist.traverse()

