# 3.3.2 p71
import sys
lst = []
empty_size = b = sys.getsizeof(lst)
count = 0
print("列表长度 %4d,  总占用字节数 %4d" % (0, b))
for k in range(500):
    lst.append(None)
    a = len(lst)
    old_b = b
    b = sys.getsizeof(lst)
    if b != old_b:
        print("列表长度 %4d,  总占用字节数 %4d, "
              " 表元素容器大小 %4d,  增加大小:%4d"
              % (a, b, (b - empty_size) / 8, (b - old_b) / 8))
        count += 1
print("扩容总次数:", count)
