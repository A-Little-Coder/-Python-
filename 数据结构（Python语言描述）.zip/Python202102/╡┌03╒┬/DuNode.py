# 3.4.3 p88
class DuNode:
    def __init__(self, entry, prior=None, next=None):
        self.entry = entry
        self.prior = prior
        self.next = next