# 3.4.1 p81
class Node:
    def __init__(self, data, link=None):
        self.entry = data
        self.next = link