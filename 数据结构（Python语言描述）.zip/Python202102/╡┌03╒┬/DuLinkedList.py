# 3.4.3 p88-89
from DuNode import DuNode

class DuLinkedList:
    def __init__(self):
        self._head = DuNode(None)
        self._head.next = self._head
        self._head.prior = self._head

    def insert(self, i, item):
        if i < 0:
            raise IndexError("插入位置不合法，i值小于0")
        previous = self._head
        count = -1
        while previous.next != self._head and count < i - 1:
            previous = previous.next
            count += 1
        following = previous.next
        if count == i-1:
            new_node = DuNode(item,previous,following)
            previous.next = new_node
            following.prior = new_node
        else:
            raise IndexError("插入位置不合法，i值太大")

    def traverse(self):
        p = self._head.next
        while p != self._head:
            print(p.entry, end=" ")
            p = p.next
        print()


if __name__ == "__main__":
    lst = DuLinkedList()
    lst.insert(0, '0')
    lst.insert(0, '5')
    lst.insert(1, '1')
    lst.insert(2, '1')
    lst.insert(3, '4')
    lst.insert(4, '9')
    lst.insert(5, 'y')
    lst.traverse()
