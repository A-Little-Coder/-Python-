# 3.3.3 p73
from AbstractList import AbstractList


class PythonList(AbstractList):
    def __init__(self):
        self._entry = []

    def __len__(self):
        return len(self._entry)

    def empty(self):
        return not self._entry

    def clear(self):
        self._entry=[]

    def insert(self, i, item):
        self._entry.insert(i, item)

    def remove(self, i):
        self._entry.pop(i)

    def retrieve(self,i):
        return self._entry[i]

    def replace(self,i, item):
        self._entry[i] = item

    def contains(self, item):
        return item in self._entry

    def traverse(self):
        print(self._entry)

    def __iter__(self):
        for item in self._entry:
            yield item


if __name__ == "__main__":
    alist = PythonList()
    print(alist.empty())
    print(len(alist))
    alist.insert(0,'5')
    alist.insert(1,'4')
    alist.insert(2,'3')
    alist.insert(3,'2')
    alist.insert(4,'1')
    for item in alist:
        print(item,end=" ")
    alist.traverse()
    alist.remove(2)
    alist.traverse()
    print(alist.retrieve(3))
    alist.replace(0,'9')
    alist.traverse()
    alist.clear()
    alist.traverse()
