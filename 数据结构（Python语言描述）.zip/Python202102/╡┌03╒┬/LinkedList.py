# 3.4.1 p81--
from AbstractList import AbstractList
from Node import Node


class LinkedList(AbstractList):
    def __init__(self):
        super().__init__()
        self._head = Node(None)

    def empty(self):
        return self._head.next is None

    def __len__(self):
        p = self._head.next
        count = 0
        while p:
            count += 1
            p = p.next
        return count

    def clear(self):
        p = self._head.next
        self._head.next = None
        while p:
            q = p
            p = p.next
            del q

    def clear(self):
        self._head.next = None

    def retrieve(self, i):
        if i < 0:
            raise IndexError("i is too small")
        p = self._head.next
        count = 0
        while p and count < i:
            p = p.next
            count += 1
        if p:
            return p.entry
        else:
            raise IndexError("i is too big")

    def insert(self, i, item):
        if i < 0:
            raise IndexError("i is too small")
        previous = self._head
        count = -1
        while previous is not None and count < i - 1:
            previous = previous.next
            count += 1
        if previous is None:
            raise IndexError("i is too big")
        new_node = Node(item, previous.next)
        previous.next = new_node

    def remove(self, i):
        if i < 0:
            raise IndexError("i is too small")
        previous = self._head
        j = -1
        while previous and j < i - 1:
            previous = previous.next
            j += 1
        if previous is None:
            raise IndexError("k is too big,no element has position k-1")
        current = previous.next
        if current is None:
            raise IndexError("k is too big,no element has position k")
        previous.next = current.next
        item = current.entry
        del current
        return item

    def replace(self, i, item):
        if i < 0:
            raise IndexError("i is too small")
        p = self._head.next
        j = 0
        while p is not None and j < i:
            p = p.next
            j += 1
        if p != None:
            p.entry = item
        else:
            raise IndexError("i is too big")

    def contains(self, item):
        p = self._head.next
        while p is not  None:
            if p.entry == item:
                return True
            p = p.next
        return False

    def traverse(self):
        p = self._head.next
        while (p != None):
            print(p.entry, end=" ")  #
            p = p.next
        print()  #

    def get_head(self):
        return self._head

    # p99-100，当前表是否小于other
    def __lt__(self, other):
        p = self._head.next
        q = other.get_head().next
        while p and q:
            if p.entry < q.entry:
                return True
            if p.entry > q.entry:
                return False
            p = p.next
            q = q.next
        if not q:   # A比B长或等长
            return False
        if not p:   # A比B短
            return True

    # 增加的迭代器
    def __iter__(self):
        p = self._head.next
        while (p != None):
            yield p.entry
            p = p.next

    # 逆置操作 p 99
    def reverse(self):
        p = self._head.next
        self._head.next = None
        while p:
            q = p.next				  # q指针指向p的下一个结点
            p.next = self._head.next		# 将p插入为首结点
            self._head.next = p
            p = q					 # p指向下一个待插入结点


def intersect1(la, lb):   # p93 无序表的交集
    m = len(la)
    n = len(lb)
    lc = LinkedList()
    for i in range(m):
        x = la.retrieve(i)
        if lb.contains(x):
            lc.insert(len(lc),x)
    return lc


# p101，逆置
def reverse(alist):
    i = 0
    j = len(alist) - 1
    while i < j:
        itema = alist.retrieve(i)
        itemb = alist.retrieve(j)
        alist.replace(i, itemb)
        alist.replace(j, itema)
        i += 1
        j -= 1

# p101，逆置
def reverse(alist):
    for i in range(0, len(alist)):
        item = alist.remove(i)
        alist.insert(0, item)


if __name__ == "__main__":
    lst = LinkedList()
    lst.insert(0, 0)
    lst.insert(1, 9)
    lst.insert(2, 8)
    lst.insert(3, 3)
    lst.insert(4, 7)
    lst.insert(5, 5)
    lst.insert(6, 6)
    lst.traverse()
    print(len(lst))
    lst.reverse()
    lst.traverse()
    reverse(lst)
    lst.traverse()



