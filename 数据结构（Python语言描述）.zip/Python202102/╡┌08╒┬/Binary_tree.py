# 8.3.3 p235 # 8.4.2 # 8.4.3 # 8.4.4  # 8.4.5 # 8.4.6
from ArrayStack import ArrayStack
from CircularQueue import CircularQueue


class BinaryNode:
    def __init__(self, data="#", left=None, right=None):
        self.data = data
        self.left = left
        self.right = right


class BinaryTree:
    def __init__(self):
        self._root = None

    def preorder(self):  # p239
        """先序遍历接口方法"""
        self.recursive_preorder(self._root)
        print()

    def recursive_preorder(self, sub_root):
        """先序遍历递归算法"""
        if sub_root:
            print(sub_root.data, end=" ")
            self.recursive_preorder(sub_root.left)
            self.recursive_preorder(sub_root.right)

    def inorder(self):
        self.recursive_inorder(self._root)
        print()

    def recursive_inorder(self, sub_root):
        if sub_root:
            self.recursive_inorder(sub_root.left)
            print(sub_root.data, end=" ")
            self.recursive_inorder(sub_root.right)

    def recursive_size(self, sub_root):  # 例8.2
        if not sub_root:
            return 0
        else:
            return 1 + self.recursive_size(sub_root.left) + \
                   self.recursive_size(sub_root.right)

    def recursive_degree1_size(self, sub_root):  # 例8.3
        if not sub_root:                                                    # 第1种形态
            return 0
        if not sub_root.left and not sub_root.right:                        # 第1种形态
            return 0
        if sub_root.left and sub_root.right:                                # 第5种形态
            return self.recursive_degree1_size(sub_root.left) + \
                   self.recursive_degree1_size(sub_root.right)
        else:                                                               # 第3、4种形态
            return 1 + self.recursive_degree1_size(sub_root.left) + \
                   self.recursive_degree1_size(sub_root.right)


    def is_strict(self):
        return self.recursive_is_strict(self._root)

    def recursive_is_strict(self, sub_root):   # 例8.4
        if not sub_root:                          # sub_root为空
            return True
        if sub_root.left and not sub_root.right:  # sub_root只有非空左孩子
            return False
        if sub_root.right and not sub_root.left:  # sub_root只有非空右孩子
            return False
        # sub_root有非空的左右孩子
        return self.recursive_is_strict(sub_root.left) and \
               self.recursive_is_strict(sub_root.right)

    # 例8.5
    def __eq__(self, other):
        """接口方法，是二叉树类的特殊方法，
        使得用户代码可以用==比较两棵二叉树是否相等。"""
        return self.recursive_eq(self._root, other._root)

    def recursive_eq(self, sub_root1, sub_root2):
        if not sub_root1 and not sub_root2:
            return True  # 情形1
        if not (sub_root1 and sub_root2):
            return False  # 情形2、3
        # 以下为情形4
        if sub_root1.data != sub_root2.data:
            return False
        return self.recursive_eq(sub_root1.left, sub_root2.left) and \
               self.recursive_eq(sub_root1.right, sub_root2.right)

    # 例8.6
    def copy(self, other):
        self._root = self.recursive_copy(other._root)

    def recursive_copy(self, sub_root):
        if not sub_root:                        # sub_root为空，返回空
            return sub_root
        new_root = BinaryNode(sub_root.data)    # 生成sub_root的拷贝new_root
        # 复制sub_root的左子树作为new_root的左子树
        new_root.left = self.recursive_copy(sub_root.left)
        # 复制sub_root的右子树作为new_root的右子树
        new_root.right = self.recursive_copy(sub_root.right)
        return new_root

    # 例8.7
    def delete_leaf(self):
        self._root = self.recursive_de_leaf(self._root)

    def recursive_de_leaf(self, sub_root):
        if not sub_root:
            return sub_root
        if not sub_root.left and not sub_root.right:
            del sub_root
            return None
        sub_root.left = self.recursive_de_leaf(sub_root.left)
        sub_root.right = self.recursive_de_leaf(sub_root.right)
        return sub_root

    def inorder(self):      # p244
        s = ArrayStack()  # s为第4章中实现的顺序栈，也可以用链栈
        p = self._root  # 活动指针p初始指向root
        while not s.empty() or p:  # 当栈s不为空栈或p不为None
            while p:  # 当p不为None时，p入栈于s，p往其左孩子移动
                s.push(p)  # p入栈于s
                p = p.left  # p往其左孩子移动
            if not s.empty():  # 如栈非空
                p = s.pop()  # 则出栈s中一个结点由p指示
                print(p.data, end=" ")  # 访问p所指结点
                p = p.right  # p调整至其右孩子
        print()

    def preorder1(self):  # p 245 修改inorder算法
        s = ArrayStack()
        p = self._root
        while not s.empty() or p:
            if p:
                print(p.data, end=" ")
                s.push(p)
                p = p.left
            else:
                p = s.pop()
                p = p.right
        print()

    def preorder2(self):  # p 245 入栈非空右孩子的算法
        p = self._root
        s = ArrayStack()  # 初始化一个空栈
        while not s.empty() or p:  #
            if p:
                print(p.data, end=" ")
                if p.right:
                    s.push(p.right)
                p = p.left
            else:
                p = s.pop()
        print()

    def postorder(self):  # p 246
        s = ArrayStack()
        p = self._root
        q = None
        while not s.empty() or p:
            while p:  # 左单支结点依次入栈
                s.push(p)
                p = p.left
            while not s.empty():
                p = s.get_top()     # 查看栈顶p
                if not p.right or p.right == q:  # 如果p没有右孩子或者p的右孩子刚访问过
                    p = s.pop()     # 出栈p
                    print(p.data, end=" ")  # 访问该结点
                    q = p  # 更新q，使其指向最近访问结点
                    if p == self._root:      # 如遇到根，则结束
                        print()
                        return
                else:
                    p = p.right
                    break

    def level_traversal(self):   # p 247
        if self._root is None:
            return
        q = CircularQueue()
        q.append(self._root)
        while not q.empty():
            p = q.serve()
            print(p.data, end=" ")
            if p.left:
                q.append(p.left)
            if p.right:
                q.append(p.right)
        print()

    def create1(self, pre):
        self._root = self.recursive_create1(pre)

    def recursive_create1(self, preorder):  # p 249
        if len(preorder) == 0:
            raise ValueError("不合法的带#先序序列")
        data = preorder.pop(0)  # 删除列表首元素，并赋值给data
        if data == '#':  # 如果data为“#”
            return None  # 生成空二叉树
        else:
            new_root = BinaryNode(data)  # 以data值生成结点new_root
            # 以删除了首元素的新preorder列表生成new_root的左子树
            new_root.left = self.recursive_create1(preorder)
            # 以删除了首元素以及new_root左子树对应元素的新preorder列表
            # 生成new_root的右子树
            new_root.right = self.recursive_create1(preorder)
            return new_root

        #  利用两个序列创建二叉树

    def create2(self, preorder, inorder):  # p 249
        if len(preorder) != len(inorder):
            print("字符串非法")
            raise ValueError("不是合法的序列")
        self._root = self.recursive_create2(preorder, inorder)

    def recursive_create2(self, preorder, inorder):
        if len(preorder) == 0:
            return None  # 序列长度为0，生成空二叉树
        root_char = preorder[0]  # rootchar为根结点值
        root_in = inorder.find(root_char)  # 在中序序列中定位根的位置
        if root_in == -1:
            print("字符串非法")
            raise ValueError("不是合法的序列")
        left_in = inorder[:root_in]  # 获得左子树的中序
        right_in = inorder[root_in + 1:]  # 获得右子树的中序
        left_pre = preorder[1:root_in + 1]  # 获得左子树的先序
        right_pre = preorder[root_in + 1:]  # 获得右子树的先序
        new_root = BinaryNode(root_char)  # 创建根结点
        new_root.left = self.recursive_create2(left_pre, left_in)
        # 用左子树的先序和中序创建根结点的左子树
        new_root.right = self.recursive_create2(right_pre, right_in)
        # 用右子树的先序和中序创建根结点的右子树
        return new_root  # 返回根结点指针

    def create3(self, lst):  # p 250
        self._root = self.recursive_create3(lst, 0)

    def recursive_create3(self, lst, i):
        """从lst的i号位置开始创建二叉树，返回生成二叉树的根结点指针"""
        if i >= len(lst):
            return None  # 返回空指针
        else:  # i号位置没有超出列表长度
            if lst[i] is None:  # 该位置为None
                return None  # 返回空指针
            new_root = BinaryNode(lst[i])  # 生成i号元素对应的结点
            # 从列表2i+1号位置开始创建左子树
            new_root.left = self.recursive_create3(lst, 2 * i + 1)
            # 从列表2i+2号位置开始创建右子树
            new_root.right = self.recursive_create3(lst, 2 * i + 2)
            return new_root  # 返回根结点指针

    def create_expression(self, postfix):  # p 251
        optr = ["*", "-", "+", "/"]  # 存放运算符的列表
        s = ArrayStack()
        # p = None
        for token in postfix:  # 对于postfix中的每个符号token
            if token not in optr:  # 如果token不是运算符，即为操作数
                s.push(BinaryNode(token))  # 生成新结点并入栈
            else:  # 如果token是运算符
                p = BinaryNode(token)  # 生成对应结点p
                p.right = s.pop()  # 出栈1个结点作为p的右孩子
                p.left = s.pop()  # 再次出栈1个结点作为p的左孩子
                s.push(p)  # 将p入栈
        self._root = s.pop()  # 出栈栈中的唯一元素即为根结点

    def print_tree(self):   # p 252
        """输出二叉树图形字符串"""
        # 调用build_tree_string获得当前二叉树的字符串列表lines
        lines = self.build_tree_string(self._root)[0]
        a = '\n' + '\n'.join((line.rstrip() for line in lines))     # 将lines列表内容进行连接
        print(a)

    def build_tree_string(self, root, delimiter='-'):
        """获得root为根的二叉树的字符串列表表示
        以及二叉树的宽度、根的起始和结束位置"""
        if root is None:
            return [], 0, 0, 0
        line1 = []  # 用于存储当前二叉树的根所在行的字符串表示
        line2 = []  # 用于存储当前二叉树根的左右分支所在行的字符串表示
        node_repr = str(root.data)
        new_root_width = gap_size = len(node_repr)
        # 递归调用获得左右子树的字符串列表表示、宽度和根的位置信息
        l_box, l_box_width, l_root_start, l_root_end = \
            self.build_tree_string(root.left,  delimiter)
        r_box, r_box_width, r_root_start, r_root_end = \
            self.build_tree_string(root.right, delimiter)
        # 生成当前根结点到左子树的字符串列表部分,在需要的地方用空格填充
        if l_box_width > 0:
            l_root = (l_root_start + l_root_end) // 2 + 1
            line1.append(' ' * (l_root + 1))
            line1.append('_' * (l_box_width - l_root))
            line2.append(' ' * l_root + '/')
            line2.append(' ' * (l_box_width - l_root))
            new_root_start = l_box_width + 1
            gap_size += 1
        else:
            new_root_start = 0
        # 生成当前根结点的列表部分
        line1.append(node_repr)
        line2.append(' ' * new_root_width)
        # 生成当前根结点到左子树的字符串列表部分,在需要的地方用空格填充
        if r_box_width > 0:
            r_root = (r_root_start + r_root_end) // 2
            line1.append('_' * r_root)
            line1.append(' ' * (r_box_width - r_root + 1))
            line2.append(' ' * r_root + '\\')
            line2.append(' ' * (r_box_width - r_root))
            gap_size += 1
        new_root_end = new_root_start + new_root_width - 1
        # 将l_box和r_box与line1和line2的内容进行合并
        gap = ' ' * gap_size
        new_box = [''.join(line1), ''.join(line2)]
        for i in range(max(len(l_box), len(r_box))):
            l_line = l_box[i] if i < len(l_box) else ' ' * l_box_width
            r_line = r_box[i] if i < len(r_box) else ' ' * r_box_width
            new_box.append(l_line + gap + r_line)
        # 返回new_box，宽度和根的位置信息
        return new_box, len(new_box[0]), new_root_start, new_root_end


if __name__ == "__main__":
    bt1 = BinaryTree()
    bt1.create1(list("69#1#5##4#27###"))
    bt1.print_tree()
    print("二叉树的先序序列：", end=" ")
    bt1.preorder1()
    print("二叉树的先序序列2：", end=" ")
    bt1.preorder2()
    print("二叉树的中序序列：", end=" ")
    bt1.inorder()
    print("二叉树的后序序列：", end=" ")
    bt1.postorder()
    print("二叉树的层次序序列：", end=" ")
    bt1.level_traversal()
    print("二叉树的结点数：", end=" ")
    print(bt1.recursive_size(bt1._root))

    bt2 = BinaryTree()
    pre = "ABCDEFGHK"
    ino = "BDCAEHGKF"
    bt2.create2(pre, ino)
    bt2.print_tree()
    print("二叉树的先序序列：", end=" ")
    bt2.preorder1()
    print("二叉树的先序序列2：", end=" ")
    bt2.preorder2()
    print("二叉树的中序序列：", end=" ")
    bt2.inorder()
    print("二叉树的后序序列：", end=" ")
    bt2.postorder()
    print("二叉树的层次序序列：", end=" ")
    bt2.level_traversal()
    print("二叉树的结点数：", end=" ")
    print(bt2.recursive_size(bt2._root))


    bt3 = BinaryTree()
    lst = ['A','B','C',None,'D',None,'E', None,None,None,None,None,None,'F']
    bt3.create3(lst)
    bt3.print_tree()
    print("二叉树的先序序列：", end=" ")
    bt3.preorder1()
    print("二叉树的先序序列2：", end=" ")
    bt3.preorder2()
    print("二叉树的中序序列：", end=" ")
    bt3.inorder()
    print("二叉树的后序序列：", end=" ")
    bt3.postorder()
    print("二叉树的层次序序列：", end=" ")
    bt3.level_traversal()
    print("二叉树的结点数：", end=" ")
    print(bt3.recursive_size(bt3._root))

    bt4 = BinaryTree()
    bt4.copy(bt3)
    bt4.print_tree()
    print(bt3 == bt2)
    print(bt4 == bt3)