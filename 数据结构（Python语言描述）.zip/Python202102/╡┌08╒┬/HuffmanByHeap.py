# 8.6.2
class HuffmanNode:
    def __init__(self):
        self.data = '#'
        self.weight = -1
        self.parent = None
        self.left = None
        self.right = None

    def __gt__(self, other):
        return self.weight > other.weight

    def __lt__(self, other):
        return self.weight < other.weight


class HuffmanTree:
    def __init__(self):
        self._root = None

    def create(self, forest):
        """ 哈夫曼树创建算法，forest为存放初始森林中各叶结点指针的堆"""
        while len(forest) > 1:  # 当forest中的二叉树棵数大于1时
            left_node = forest.del_min()  # 连续删除堆顶的两个权值最小的根结点
            right_node = forest.del_min()
            new_node = HuffmanNode()  # 生成双亲结点new_node
            new_node.weight = left_node.weight + right_node.weight
            # new_node结点与它左右孩子结点之间指针域的连接
            new_node.left = left_node
            new_node.right = right_node
            left_node.parent = new_node
            right_node.parent = new_node
            forest.insert(new_node)  # new_node插入到forest堆
        self._root = forest.del_min()  # 堆顶结点即为哈夫曼树的根

    def huffman_encoding(self, leaf):
        print('各字符的哈夫曼编码如下：')
        for i in range(len(leaf)):  # 对于leaf堆中的每个叶子结点
            p = leaf.del_min()  # p指向堆顶叶子结点
            print(p.data, end=":")  # 输出该叶子对应的字符值
            t_code = []  # t_code用于存储该叶子的哈夫曼编码
            while p != self._root:  # 当p还未到达根结点
                if p.parent.left == p:  # 如果p为其双亲的左孩子
                    t_code.append('0')  # 将0插入到t_code尾部
                else:  # 如果p为其双亲的右孩子
                    t_code.append('1')  # 将1插入到t_code尾部
                p = p.parent  # p移动至它的双亲
            t_code.reverse()    # t_code逆置后才是该字符的哈夫曼
            print(''.join(i for i in t_code))  # 输出该字符的哈夫曼编码

    def print_tree(self):
        lines = self._build_tree_string(self._root, 0)[0]
        a = '\n' + '\n'.join((line.rstrip() for line in lines))
        print(a)

    def _build_tree_string(self, root, curr_index, delimiter='-'):
        if root is None:
            return [], 0, 0, 0

        line1 = []
        line2 = []
        if root.data == "#":
            node_repr = str(root.weight)
        else:
            node_repr = str(root.data)+"("+ str(root.weight)+")"

        new_root_width = gap_size = len(node_repr)

        # Get the left and right sub-boxes, their widths, and root repr positions
        l_box, l_box_width, l_root_start, l_root_end = \
            self._build_tree_string(root.left, 2 * curr_index + 1, delimiter)
        r_box, r_box_width, r_root_start, r_root_end = \
            self._build_tree_string(root.right, 2 * curr_index + 2, delimiter)

        # Draw the branch connecting the current root node to the left sub-box
        # Pad the line with whitespaces where necessary
        if l_box_width > 0:
            l_root = (l_root_start + l_root_end) // 2 + 1
            line1.append(' ' * (l_root + 1))
            line1.append('_' * (l_box_width - l_root))
            line2.append(' ' * l_root + '/')
            line2.append(' ' * (l_box_width - l_root))
            new_root_start = l_box_width + 1
            gap_size += 1
        else:
            new_root_start = 0

        # Draw the representation of the current root node
        line1.append(node_repr)
        line2.append(' ' * new_root_width)

        # Draw the branch connecting the current root node to the right sub-box
        # Pad the line with whitespaces where necessary
        if r_box_width > 0:
            r_root = (r_root_start + r_root_end) // 2
            line1.append('_' * r_root)
            line1.append(' ' * (r_box_width - r_root + 1))
            line2.append(' ' * r_root + '\\')
            line2.append(' ' * (r_box_width - r_root))
            gap_size += 1
        new_root_end = new_root_start + new_root_width - 1

        # Combine the left and right sub-boxes with the branches drawn above
        gap = ' ' * gap_size
        new_box = [''.join(line1), ''.join(line2)]
        for i in range(max(len(l_box), len(r_box))):
            l_line = l_box[i] if i < len(l_box) else ' ' * l_box_width
            r_line = r_box[i] if i < len(r_box) else ' ' * r_box_width
            new_box.append(l_line + gap + r_line)

        # Return the new box, its width and its root repr positions
        return new_box, len(new_box[0]), new_root_start, new_root_end


def create_leaf_nodes(data_and_weights):
    """创建leaf_nodes堆，存储初始森林中所有叶子结点的指针"""
    leaf_nodes = BinHeap()
    for key, value in data_and_weights.items():
        new_node = HuffmanNode()		# 生成三叉链表叶子结点new_node
        new_node.data = key       	# 叶子的值填入new_node的data域
        new_node.weight = value		# 叶子的权值填入new_node的weight域
        leaf_nodes.insert(new_node)		# 调用堆的插入算法将new_node插入堆中
    return leaf_nodes


from binheap import BinHeap
import copy
if __name__ == "__main__":
    data_and_weights = { 'C': 2, 'A': 17, 'S': 4, 'T': 5}
    huffman = HuffmanTree()		# 初始化空哈夫曼树对象huffman
    # 创建存储所有叶子结点指针的堆leaf_nodes
    leaf_nodes = create_leaf_nodes(data_and_weights)
    # forest复制了leaf_nodes堆
    # 即forest和leaf_nodes堆的每个元素分别依次存放各叶子结点指针。
    forest = copy.copy(leaf_nodes)
    # 由初始森林forest创建哈夫曼树huffman
    huffman.create(forest)
    # 输出哈夫曼树，此处修改了build_tree_string算法以显示每个结点的权值
    huffman.print_tree()
    # 利用leaf_nodes堆生成并输出哈夫曼编码，注意forest现已为空
    huffman.huffman_encoding(leaf_nodes)
