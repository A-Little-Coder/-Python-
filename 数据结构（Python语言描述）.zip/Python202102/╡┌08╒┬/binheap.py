# 8.5.3
class BinHeap:
    def __init__(self):
        self.data = []

    def __copy__(self):
        new_heap = BinHeap()
        new_heap.data = list(self.data)
        return new_heap

    def __test__(self):
        self.data.append("ok")
        print(self.data)

    def __len__(self):
        return len(self.data)

    def insert(self, x):
        self.data.append(x)
        self.sift_up(len(self.data) - 1)

    def sift_up(self, i):
        """ 从i号位置开始向上筛选"""
        # 由于列表中元素下标从0开始编号，i号元素的父结点编号为(i-1)//2。
        while (i-1) // 2 >= 0:  # 最坏情况筛选到根，即0号位置
            if self.data[i] < self.data[(i-1) // 2]:        # 如果i号结点小于其父结点，则交换这对父子
                self.data[(i - 1) // 2], self.data[i] = self.data[i], self.data[(i - 1) // 2]
            i = (i - 1) // 2                # i更新为其父结点编号

    def del_min(self):
        min_val = self.data[0]  # 暂存原堆顶的值
        self.data[0] = self.data[len(self.data) - 1]  # 将最后一个叶子替换到堆顶
        self.data.pop()  # 删除列表中最后一个叶子
        if len(self.data) > 0:  # 如果堆中还有元素
            self.sift_down(0, len(self.data) - 1)  # 从0号位置（堆顶）开始向下筛选
        return min_val  # 返回被删除原堆顶的值

    def sift_down(self, i, end):
        """对当前堆从i号位置开始向下筛选，筛选结束位置为end"""
        j = 2 * i + 1  # j为i号结点的左孩子编号
        x = self.data[i]  # 当前堆顶的值
        while j <= end:
            if j < end and self.data[j + 1] < self.data[j]:
                j = j + 1  # j为i号结点更小孩子的编号
            if x < self.data[j]:
                break  # x应在i号位置
            else:
                # 更小的孩子j号应该与父结点i号交换，但由于j号位置并不一定
                # 是x的最终位置，在此只做单方向赋值，只将该孩子提升到i号位置
                self.data[i] = self.data[j]
                i = j  # i赋值为更小孩子的编号
                j = 2 * j + 1  # j为i的左孩子
        self.data[i] = x  # x填入最终位置i

    def build_heap(self, lst):
        i = (len(lst) - 2) // 2
        self.data = lst[:]
        while i >= 0:
            self.sift_down(i, len(lst) - 1)
            i = i - 1

import copy
if __name__ == "__main__":
    bh = BinHeap()
    bh2 = BinHeap()
    lst1 = [9, 10, 5, 6, 2, 3]
    bh2.build_heap(lst1)
    bh = copy.copy(bh2)

    print(bh.del_min())
    print(bh.del_min())
    print(bh.del_min())
    print(bh.del_min())
    print(bh.del_min())
    print(bh.del_min())
