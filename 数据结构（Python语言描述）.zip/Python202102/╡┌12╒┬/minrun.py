def getMinrun(n):
    r = 0
    while n >= 64:
        b = n & 1
        r = r | b
        n >>= 1
    return n + r


print(getMinrun(3000))

