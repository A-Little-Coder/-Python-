﻿import time
import random
import sys


from Record import Record


class SortableList:
    def __init__(self):
        self.data = []

    def create(self, alst):
        for i in range(len(alst)):
            self.data.append(Record(int(alst[i]), i))

    def traverse(self):
        for i in range(0, len(self.data)):
            print(self.data[i].key, end=" ")

    def insertion_sort(self):
        for i in range(1, len(self.data)):  # 依次将i号记录插入在表中0至i-1部分的有序序列中
            if self.data[i] < self.data[i - 1]:
                temp = self.data[i]
                j = i - 1
                while j >= 0 and self.data[j] > temp:  # 依次与之前的每个记录关键字比较
                    self.data[j + 1] = self.data[j]  # 如前面记录更大则后移
                    j -= 1  # j往前移动
                self.data[j + 1] = temp  # temp记录放在j+1位置


    def bin_insertion_sort(self):
        data_len = len(self.data)
        for i in range(1, data_len):
            if self.data[i] < self.data[i - 1]:
                low = 0
                high = i - 1
                # temp = Record(self.data[i].key, self.data[i].value)
                temp =self.data[i]
                while low <= high:
                    mid = (low + high) // 2
                    if temp < self.data[mid]:
                        high = mid - 1
                    else:
                        low = mid + 1
                j = i - 1
                while j >= low:
                    self.data[j + 1] = self.data[j]
                    j = j - 1
                self.data[low] = temp

    def shell_sort(self):
        data_len = len(self.data)
        gap = data_len
        while True:
            gap = gap // 3 + 1
            for i in range(gap, data_len):
                # temp = Record(self.data[i].key, self.data[i].value)
                temp = self.data[i]
                j = i - gap
                while j >= 0 and self.data[j] > temp:
                    self.data[j + gap] = self.data[j]
                    j -= gap
                self.data[j + gap] = temp
            if gap == 1:
                break

    def bubble_sort(self):
        data_len = len(self.data)
        for i in range(data_len - 1, 0, -1):  # 获得i号位置的正确值
            for j in range(0, i):
                if self.data[j] > self.data[j + 1]:
                    self.data[j], self.data[j + 1] = self.data[j + 1], self.data[j]

    def bubble_sort2(self):
        data_len = len(self.data)
        for i in range(data_len - 1, 0, -1):  # 获得i号位置的正确值
            exchange = False
            for j in range(0, i):
                if self.data[j] > self.data[j + 1]:
                    self.data[j], self.data[j + 1] = self.data[j + 1], self.data[j]
                    exchange = True
            if not exchange:
                break

    def partition(self, low, high):
        last_small = low
        for i in range(low + 1, high + 1):
            if self.data[i] < self.data[low]:
                last_small = last_small + 1
                self.swap(last_small, i)
        self.swap(low, last_small)
        return last_small


    def swap(self, i, j):  # 将i号和j号位置的记录交换
        self.data[i], self.data[j] = self.data[j], self.data[i]

    def recursive_quickSort(self, low, high):
        if low < high:
            self.swap(low,(low+high)//2)
            pivot_position = self.partition(low, high)
            self.recursive_quickSort(low, pivot_position - 1)
            self.recursive_quickSort(pivot_position + 1, high)

    def quick_sort(self):
        self.recursive_quickSort(0, len(self.data) - 1)


    def selection_sort(self):
        for i in range(0, len(self.data) - 1):
            min = i
            for j in range(i + 1, len(self.data)):
                if self.data[min] > self.data[j]:
                    min = j
            self.data[min], self.data[i] = self.data[i], self.data[min]

    def selection_sort2(self):
        for i in range(0, len(self.data) - 1):
            min = i
            for j in range(i + 1, len(self.data)):
                if self.data[min] > self.data[j]:
                    min = j
            if min != i:
                self.data[min], self.data[i] = self.data[i], self.data[min]

    def sift_down(self, i, end):
        # temp = Record(self.data[i].key, self.data[i].value)
        temp = self.data[i]
        j = 2 * i + 1
        while j <= end:
            if j < end and self.data[j].key < self.data[j + 1].key:
                j = j + 1
            if temp.key > self.data[j].key:
                break
            else:
                self.data[i] = self.data[j]
                i = j
                j = 2 * j + 1
        self.data[i] = temp

    def heap_sort(self):
        data_len = len(self.data)
        # 从最后一个非叶结点开始，将每个非叶结点为根的子树部分调整成堆
        for i in range(data_len // 2 - 1, -1, -1):
            self.sift_down(i, data_len - 1)
        for j in range(data_len-1, 0, -1):
            # 堆顶与j号元素交换
            self.data[0], self.data[j] = self.data[j], self.data[0]
            # 将序列中0号至j-1号部分调整成堆
            self.sift_down(0, j - 1)

    def merge_sort(self):
        m = 1  # m为已排序的子序列长度，初值为1
        n = len(self.data)
        temp = [None for i in range(0, n)]
        while m < n:
            self.merge_pass(self.data, temp, m)
            # 一趟归并，将data数组中各个最长长度为m的有序子序列归并到temp中
            m *= 2  # 子序列长度加倍
            if m >= n:
                self.data = temp[::]
            else:
                self.merge_pass(temp, self.data, m)
                # 将temp数组中各子序列再归并到r中
                m *= 2

    def merge_pass(self, source, dest, m):
        n = len(source)
        p = 0
        # 步骤1.两两归并source中长度为m的两个相邻子表
        while p + 2 * m - 1 <= n - 1:
            self.merge(source, dest, p, p + m - 1, p + 2 * m - 1)
            # 将source[p..p+m-1]和source[p+m..p+2m-1]两个有序表归并到dest[p..p+2m-1]中
            p += 2 * m
        if p + m - 1 >= n - 1:
            # 如果步骤1做完后只剩1个有序子表，将该子表中的内容复制到dest相应区域
            for i in range(p, n):
                dest[i] = source[i]
        else:
            self.merge(source, dest, p, p + m - 1, n - 1)
            # 如果步骤1做完后还剩两个子表，第1个长度为m，第2个长度小于m
            # 归并最后两个长度不等的有序表

    def merge(self, source, dest, start, mid, end):
        """source列表start~mid区间的有序左子表和source列表mid+1~end有序右子表
          归并到dest列表start~end区间"""
        if source[mid] <= source[mid + 1]:  # source中从start到end的所有数据已经有序
            for i in range(start, end + 1):
                dest[i] = source[i]  # source所有内容复制到dest对应位置
            return
        i = start  # i为左子表当前位置
        j = mid + 1  # j为右子表当前位置
        k = start  # k为dest表当前位置
        while i <= mid and j <= end:  # i和j都未超出相应子表右边界
            if source[i] <= source[j]:  # 左子表当前元素小于等于右子表当前元素
                dest[k] = source[i]
                i += 1
            else:
                dest[k] = source[j]  # 右子表当前元素更小
                j += 1
            k += 1
        while i <= mid:  # 右子表处理完毕，复制左子表剩余元素到目标表
            dest[k] = source[i]
            k += 1
            i += 1
        while j <= end:  # 左子表处理完毕，复制右子表剩余元素到目标表
            dest[k] = source[j]
            k += 1
            j += 1

    def merge_sort2(self):
        temp = [None for i in range(0, len(self.data))]
        self.recursive_mergeSort(self.data, 0, len(self.data) - 1, temp)

    def recursive_mergeSort(self, source, left, right, temp):
        if left < right:
            mid = (left + right) // 2
            self.recursive_mergeSort(source, left, mid, temp)
            self.recursive_mergeSort(source, mid + 1, right, temp)
            self.merge(source, temp, left, mid, right)
            for i in range(left, right + 1):
                source[i] = temp[i]


if __name__ == '__main__':
    sys.setrecursionlimit(10000)

    to_sort_list = [53, 7, 52, 1, 98, 10, 87, 25, 63, 46, 12]

    n = 500
    to_sort_list = [random.randint(0, 4 * n) for i in range(n)]
    print(to_sort_list)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.bubble_sort()
    print('冒泡排序1算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.bubble_sort2()
    print('冒泡排序2算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.quick_sort()
    print('快速排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.insertion_sort()
    print('插入排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.bin_insertion_sort()
    print('折半插入排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.shell_sort()
    print('希尔排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.selection_sort()
    print('选择排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.heap_sort()
    print('堆排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.merge_sort()
    print('归并排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

    sl = SortableList()
    sl.create(to_sort_list)
    start = time.perf_counter()
    sl.merge_sort2()
    print('递归归并排序算法结果为:')
    sl.traverse()
    end = time.perf_counter()
    print()
    print(end - start)

