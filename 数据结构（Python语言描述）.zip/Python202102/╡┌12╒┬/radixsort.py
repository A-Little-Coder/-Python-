class Node:
    def __init__(self, data, link=None):
        self.entry = data
        self.next = link


class LinkedList:
    def getHead(self):
        return self._head

    def setHead(self,p):
        self._head.next = p

    def __init__(self):
        self._head = Node(None)

    def empty(self):
        return self._head.next is None

    def insert(self, i, item):
        if i < 0:
            raise IndexError("i is too small")
        previous = self._head
        count = -1
        while previous and count < i - 1:
            previous = previous.next
            count += 1
        if previous is None:
            raise IndexError("i is too big")
        new_node = Node(item, previous.next)
        previous.next = new_node

    def traverse(self):
        p = self._head.next
        while p:
            print(p.entry, end=" ")  #
            p = p.next
        print()  #

    def distribute(self, p, i):
        """将p为首结点的单链表中各记录按关键字第i位分配到j号队列
        i=0表示个位，i=1表示十位，以此类推"""
        # queues[j][0]和queues[j][1]将分别存储j号队列的队首和队尾
        queues = [[None, None] for i in range(10)]
        while p:
            # j = p.entry // 10 ** i % 10  # 获得p结点第i位数字对应队列号j
            j = (p.entry // (10 ** i)) % 10	    # j为p结点的关键字第i位数字对应队列号
            q = p.next  # 用q指针暂存p的下一个结点
            # 将p结点插入到j号链队列末尾
            if not queues[j][0]:  # 原j号队列为空，结点p插入为j号队列首结点
                queues[j][0] = queues[j][1] = p
            else:  # 否则，结点p插入在j号队列末尾
                queues[j][1].next = p
                queues[j][1] = p
            p.next = None  # 设置p结点的指针域为空
            p = q  # 继续处理下一个结点
        return queues  # 返回队列列表

    def collect(self, queues):
        """对queues中的10条队列进行收集 """
        front = rear = None  # front和rear为收集结果链表的头、尾位置
        first = True  # first为第一次遇到非空队列标记
        for j in range(10):
            if queues[j][0]:
                if first:  # 第一次遇到非空队列，该队列队首赋值给front
                    front = queues[j][0]
                    first = False
                else:  # 已收集链表的尾指针rear与当前队首连接
                    rear.next = queues[j][0]
                rear = queues[j][1]  # 已收集链表队尾更新为当前队列队尾
        return front  # 返回一趟收集结果链表的头指针

    def radix_sort(self, d):
        p = self.getHead().next     # 获得排序链表首记录结点p
        # 作 d次分配和收集
        for i in range(d):
            queues = self.distribute(p, i)       # 对当前单链表中每个记录结点进行分配
            # 将队列中的各条非空链表连接成一条链表，p指示该链表首结点
            p = self.collect(queues)
        self._head.next = p


if __name__ == "__main__":
    q = LinkedList()
    to_sort_list = [53, 17, 152, 11, 98, 310, 487, 918, 125, 263, 46]
    for i in range(0, len(to_sort_list)):
        q.insert(i, to_sort_list[i])
    q.radix_sort(3)
    q.traverse()



