
def bf(s, t):
    slen, tlen = len(s), len(t)
    i, j = 0, 0
    while i <slen and j < tlen:
        if s[i] == t[j]:
            i += 1
            j += 1
        else:
            i = i-j + 1
            j = 0
    if j == tlen:
        return i - j
    else:
        return -1


def kmp(s, t, pnext):
    i, j = 0, 0
    slen, tlen = len(s), len(t)
    while i < slen and j < tlen:
        if j == -1 or s[i] == t[j]:
            i, j = i+1, j+1
        else:
            j = pnext[j]
    if j == tlen:
        return i-j
    return -1


def gen_next(t):
    j, k, tlen = 0, -1, len(t)
    pnext = [-1]*tlen
    while j < tlen-1:
        if k == -1 or t[j] == t[k]:
            pnext[j+1] = k+1
            j, k = j + 1, k + 1
        else:
            k = pnext[k]
    return pnext


s="000000001"
t="000001"

s="ababcabcacbab"
t="abcac"

s = "ababbaa"
t= "ababaaa"

a = bf(s, t)
print(a)
pnext=gen_next(t)
print(pnext)
a=kmp(s,t,pnext)
print(a)

