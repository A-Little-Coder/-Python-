
from ctypes import *
tenIntegers = c_long * 5 * 2
m = tenIntegers((1, 2, 3, 4, 5),(6, 7, 8, 9))
print(m)
for i in m:
    for j in i:
        print(j, end=" ")
    print()

from array import array
primes = array('i', [1030, 8141, 2507])
print(primes)
for i in primes:
    print(i, end=" ")
print()

import numpy as np
c = np.arange(24).reshape(2, 3, 4)
print(c)