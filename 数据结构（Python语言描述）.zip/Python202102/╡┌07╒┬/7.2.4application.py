from PIL import Image					# 引入Python图像库PIL中的Image类
import numpy as np
import matplotlib.pyplot as plt			# 引入matplotlib.pyplot用于绘图
# 读取彩色图片python.jpg，灰度化，并转为数组
image_array1 = np.array(Image.open("python.jpg").convert('L'))
image_array2 = 255 - image_array1		# 对图像进行反相处理
plt.subplot(121)						# 1行2列显示，第1列显示原灰度图
plt.gray()
plt.imshow(image_array1)
plt.subplot(122) 						# 1行2列显示，第2列显示反相图
plt.gray()
plt.imshow(image_array2)
plt.show()



