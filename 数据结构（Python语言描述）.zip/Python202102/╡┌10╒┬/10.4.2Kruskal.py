# 10.4.2 kruskal 算法
# 无向连通网邻接矩阵结构 g8

class Vertex:
    def __init__(self, data=None):
        self.data = data


class CloseEdge:
    def __init__(self, lowcost, adjvetex):
        self.lowcost = lowcost
        self.adjvetex = adjvetex

class UDNGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [Vertex() for i in range(0, max_vertex)]
        self._arcs = [[float("inf") for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        for i in range(max_vertex):
            self._arcs[i][i] = 0
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1
        return self._vertexNum

    def addEdge(self, v, w, cost):
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        self._arcs[i][j] = int(cost)
        self._arcs[j][i] = int(cost)
        self._arcNum += 1   #

    def locateVertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index

    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0,self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4d" % (self._arcs[i][j]), end=" ")
            print()

    def get_edges(self):
        edges = []
        for i in range(self._vertexNum):
            for j in range(i + 1, self._vertexNum):
                if self._arcs[i][j] != 0 and self._arcs[i][j] != float("inf"):
                    k = len(edges) - 1
                    while k >= 0 and edges[k][2] > self._arcs[i][j]:
                        k -= 1
                    if k == len(edges) - 1:
                        edges.append((i, j, self._arcs[i][j]))
                    else:
                        edges.insert(k + 1, (i, j, self._arcs[i][j]))
        return edges

    def kruskal(self):
        edges =self.get_edges()
        component = [i for i in range(self._vertexNum)]  # 存放每个顶点的连通分量编号
        result = []  # 用于存放生成树的边
        k = 0  # 当前正在处理的edges中边的序号
        count = 0
        # 依次考察edges[k]，当符合条件时加入result中
        # 直至result满n-1条边或所有边已检查过
        while count < self._vertexNum-1 and k < len(edges):
            u = edges[k][0]  # edges[k]的一个顶点u
            v = edges[k][1]  # edges[k]的另一个顶点v
            first = component[u]  # u处于first连通分量
            second = component[v]  # v处于second连通分量
            if first != second:
                # 若u,v不属于同一连通分量，则将edges[k]加入到生成树边集result中
                # 并将second连通分量合并到到first连通分量内
                # 即更改second连通分量内的所有顶点的component值为first
                result.append(edges[k])
                count += 1
                for w  in range(self._vertexNum):
                    if component[w] == second:
                        component[w] = first
            k += 1
        if count == self._vertexNum-1:
            print("组成最小生成树的边依次为：")
            for item in result:  # 输出最小生成树的边
                print(item)
        else:
            print("该无向网不连通，无法求解生成树")




if __name__ == "__main__":
    g8 = UDNGraphMatrix()
    g8.addVertex('0')
    g8.addVertex('1')
    g8.addVertex('2')
    g8.addVertex('3')
    g8.addVertex('4')
    g8.addVertex('5')
    g8.addEdge('0', '1', 4)
    g8.addEdge('0', '5', 2)
    g8.addEdge('0', '4', 3)
    g8.addEdge('1', '2', 2)
    g8.addEdge('1', '5', 6)
    g8.addEdge('2', '5', 5)
    g8.addEdge('2', '3', 6)
    g8.addEdge('3', '5', 3)
    g8.addEdge('3', '4', 7)
    g8.addEdge('4', '5', 1)
    g8.kruskal()


