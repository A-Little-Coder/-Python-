# 10.6 广度优先拓扑排序和深度优先拓扑排序
# 有向无环图G11 邻接表结构下

from CircularQueue import CircularQueue
class Vertex:
    def __init__(self, data):
        self.data = data
        self.firstArc = None


class Arc:
    def __init__(self, adjacent, next=None):
        self.adjacent = adjacent
        self.nextArc = next


class DGraphAdjList:
    def __init__(self):
        self._vertexNum = 0
        self._arcNum = 0
        self._vertices = []

    def locateVertex(self, v):
        for i in range(self._vertexNum):
            if v == self._vertices[i].data:
                return i
        return -1

    def addVertex(self, data):
        self._vertexNum += 1
        newVertex = Vertex(data)
        self._vertices.append(newVertex)

    def addEdge(self, v, w):
        self._arcNum += 1
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        edge_node1 = Arc(j, self._vertices[i].firstArc)
        self._vertices[i].firstArc = edge_node1

    def graph_out(self):
        for i in range(self._vertexNum):
            p = self._vertices[i].firstArc
            print(self._vertices[i].data, ":", end="  ")
            while p is not None:
                if p.nextArc is not None:
                    print(p.adjacent,  end=" -> ")
                else:
                    print(p.adjacent,end=" ")
                p = p.nextArc
            print()

    def findIndegree(self):
        indegree =[0 for i in range(self._vertexNum)]
        for u in range(0, self._vertexNum):
            v = self._vertices[u].firstArc
            while v:
                indegree[v.adjacent] += 1
                v = v.nextArc
        return indegree

    def bfsTopological(self):
        indegree = self.findIndegree()  # 找出每个顶点的入度存放在indegree列表中
        vertexQueue = CircularQueue()  # 用于存放入度为0的顶点的队列
        topoOrder = []
        # 所有入度为0的顶点入队列
        for i in range(self._vertexNum):
            if indegree[i] == 0:
                vertexQueue.append(i)
        while len(vertexQueue) > 0:
            u = vertexQueue.serve()
            topoOrder.append(self._vertices[u].data)  # 出队队首顶点u，加入到拓扑序列
            vnode = self._vertices[u].firstArc
            while vnode:
                v = vnode.adjacent
                indegree[v] -= 1  # u的所有邻接点v的入度值减1
                if indegree[v] == 0:
                    vertexQueue.append(v)  # 若该邻接点的入度变为0，则入队
                vnode = vnode.nextArc
        return topoOrder

    def dfsTopological(self):
        # 与10.3.1节中dfsTaverse的不同就在于设了topoOrder列表用于存放拓扑序列
        visited = [False for i in range(self._vertexNum)]
        topoOrder = []
        for i in range(self._vertexNum):
            if not visited[i]:
                self.dfsTopo(visited, i, topoOrder)
        return topoOrder


    def dfsTopo(self, visited, v, topoOrder):
        # 与与10.3.1节中dfs的不同在于多了参数topoOrder列表
        # 在v开始的dfs遍历结束时，将v插入在列表的0号位置
        visited[v] = True
        vjnode = self._vertices[v].firstArc
        while vjnode:
            w = vjnode.adjacent
            if not visited[w]:
                self.dfsTopo(visited, w, topoOrder)
            vjnode = vjnode.nextArc
        topoOrder.insert(0, self._vertices[v].data)


if __name__ == '__main__':
    g11 = DGraphAdjList()
    edgeList = [(0, 5), (0, 1), (1, 7), (3, 8),
                (3, 7), (3, 4), (3, 2), (4, 8),
                (6, 2), (6, 0), (8, 7), (8, 2), (9, 4)]
    for vertex in range(10):
        g11.addVertex(str(vertex))
    for edge in edgeList:
        g11.addEdge(str(edge[0]), str(edge[1]))
    print("广度优先拓扑排序序列：", g11.bfsTopological())
    print("深度优先拓扑排序序列：", g11.dfsTopological())





