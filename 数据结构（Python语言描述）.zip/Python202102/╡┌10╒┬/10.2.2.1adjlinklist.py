# 10.2.2 1 无向网邻接单链表表示
# 本程序对G3进行测试
class Vertex:
    def __init__(self, data):
        self.data = data
        self.firstArc = None


class Arc:
    def __init__(self, adjacent, weight, next=None):
        self.adjacent = adjacent
        self.weight = weight
        self.nextArc = next


class UDNGraphAdjList:
    def __init__(self):
        self._vertexNum = 0
        self._arcNum = 0
        self._vertices = []

    def locateVertex(self, v):
        for i in range(self._vertexNum):
            if v == self._vertices[i].data:
                return i
        return -1

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices.append(newVertex)
        self._vertexNum += 1


    def addEdge(self, v, w, weight):
        i = self.locateVertex(v)
        if i == -1:
            self.addVertex(v)
            i = self._vertexNum - 1
        j = self.locateVertex(w)
        if j == -1:
            self.addVertex(w)
            j = self._vertexNum - 1
        edge_node1 = Arc(j, weight, self._vertices[i].firstArc)
        self._vertices[i].firstArc = edge_node1
        edge_node2 = Arc(i, weight, self._vertices[j].firstArc)
        self._vertices[j].firstArc = edge_node2
        self._arcNum += 1

    def create(self):
        a, b = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(a)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(b)):
            a, b, weight = input().split()
            self.addEdge(a, b, weight)

    def graph_out(self):
        for i in range(self._vertexNum):
            print(i, ":", self._vertices[i].data, end="")
            p=self._vertices[i].firstArc
            while p:
                print("->", p.adjacent, '|', p.weight, end=" ")
                p = p.nextArc
            print()


if __name__ == "__main__":
    g3 = UDNGraphAdjList()
    g3.addVertex('A')
    g3.addVertex('B')
    g3.addVertex('C')
    # g3.addVertex('D')
    # g3.addVertex('E')
    # g3.addVertex('F')
    g3.addEdge('A', 'B', 10)
    g3.addEdge('A', 'C', 2)
    g3.addEdge('B', 'D', 7)
    g3.addEdge('D', 'E', 2)
    g3.addEdge('B', 'F', 5)
    g3.addEdge('E', 'F', 5)
    g3.graph_out()




