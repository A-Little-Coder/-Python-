# 10.3.1 --10.3.2在邻接表结构下
# 实现图的深度优先和广度优先搜索
# 本程序对无向图 G7进行遍历
from CircularQueue import CircularQueue


class Vertex:
    def __init__(self, data):
        self.data = data
        self.firstArc = None


class Arc:
    def __init__(self, adjacent, next=None):
        self.adjacent = adjacent
        self.nextArc = next


class UDGraphAdjList:
    def __init__(self):
        self._vertexNum = 0
        self._arcNum = 0
        self._vertices = []

    def locateVertex(self, v):
        for i in range(self._vertexNum):
            if v == self._vertices[i].data:
                return i
        return -1

    def addVertex(self, data):
        self._vertexNum += 1
        newVertex = Vertex(data)
        self._vertices.append(newVertex)

    def addEdge(self, v, w):
        self._arcNum += 1
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        edge_node1 = Arc(j, self._vertices[i].firstArc)
        self._vertices[i].firstArc = edge_node1
        edge_node2 = Arc(i, self._vertices[j].firstArc)
        self._vertices[j].firstArc = edge_node2

    def create(self):
        a, b = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(a)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(b)):
            a, b = input().split()
            self.addEdge(a, b)

    def graph_out(self):
        for i in range(self._vertexNum):
            p = self._vertices[i].firstArc
            print(self._vertices[i].data, ":", end="  ")
            while p:
                if p.nextArc:
                    print(p.adjacent,  end=" -> ")
                else:
                    print(p.adjacent,end=" ")
                p = p.nextArc
            print()

    def firstAdjVertex(self, v):
        firstArc = self._vertices[v].firstArc
        if firstArc:
            return firstArc.adjacent
        else:
            return -1

    def nextAdjVertex(self, v, adjacent):
        # 得到顶点v相对于adjacent的下一个邻接点
        p = self._vertices[v].firstArc
        while p:
            if p.adjacent == adjacent:
                if p.nextArc:
                    return p.nextArc.adjacent
                else:
                    return -1
            else:
                p = p.nextArc

    # 深度优先遍历图的算法
    def dfsTraverse(self):
        print("该图的深度优先搜索序列为：", end=" ")
        visited = [False for i in range(self._vertexNum)]
        for i in range(self._vertexNum):
            if not visited[i]:
                self.dfs(visited, i)

    # 深度优先遍历图的递归算法
    def dfs(self, visited, v):
        self.visitVertex(v)  # 访问顶点v
        visited[v] = True  # 置顶点v访问标记为True
        nextAdj = self.firstAdjVertex(v)  # 寻找v的第一个邻接点nextAdj
        while nextAdj != -1:  # 当邻接点nextAdj存在时
            if not visited[nextAdj]:  # 如果nextAdj未被访问
                self.dfs(visited, nextAdj)  # 从nextAdj开始深度优先遍历
            nextAdj = self.nextAdjVertex(v, nextAdj)  # 寻找v的下一个邻接点nextAdj

    # 访问图中某一顶点的方法
    def visitVertex(self, v):
        print(self._vertices[v].data, end=' ')

    def bfsTraverse(self):
        print("该图的广度优先搜索序列为：", end=" ")
        visited = [False for i in range(self._vertexNum)]
        for i in range(self._vertexNum):
            if not visited[i]:
                self.bfs(visited, i)

    # 广度优先遍历图的算法
    def bfs(self, visited, v):
        q = CircularQueue()
        visited[v] = True
        self.visitVertex(v)
        q.append(v)
        while not q.empty():
            u = q.serve()
            nextAdj = self.firstAdjVertex(u)
            while nextAdj != -1:
                if not visited[nextAdj]:
                    self.visitVertex(nextAdj)
                    visited[nextAdj] = True
                    q.append(nextAdj)
                nextAdj = self.nextAdjVertex(u, nextAdj)


if __name__ == "__main__":
    g7 = UDGraphAdjList()
    edgeList = [(0, 1), (0, 5), (1, 2), (2, 3),
                (2, 5), (4, 5), (4, 6), (4, 8),
                (5, 6), (5, 7), (6, 7)]
    for i in range(9):
        g7.addVertex(str(i))
    for edge in edgeList:
        g7.addEdge(str(edge[0]), str(edge[1]))
    g7.graph_out()
    g7.dfsTraverse()
    print()
    g7.bfsTraverse()
'''
对G7运行结果
0 5 7 6 4 8 2 3 1 
0 5 1 7 6 4 2 8 3 
'''

# g7.addVertex('0')
# g7.addVertex('1')
# g7.addVertex('2')
# g7.addVertex('3')
# g7.addVertex('4')
# g7.addVertex('5')
# g7.addVertex('6')
# g7.addVertex('7')
# g7.addVertex('8')
# g7.addEdge('0', '1')
# g7.addEdge('0', '5')
# g7.addEdge('1', '2')
# g7.addEdge('2', '3')
# g7.addEdge('2', '5')
# g7.addEdge('4', '5')
# g7.addEdge('4', '6')
# g7.addEdge('4', '8')
# g7.addEdge('5', '6')
# g7.addEdge('5', '7')
# g7.addEdge('6', '7')