# 10.2.1.2 无向网的邻接矩阵
# 本程序对G3进行测试
import sys
from CircularQueue import CircularQueue


class Vertex:
    def __init__(self, data=None):
        self.data = data

##################################################################
# 图初始化时有个最大顶点数，邻接矩阵的最大阶数随之确定，一旦顶点数超出，则出错


class UDNGraphMatrix:
    def __init__(self, max_vertex=16):
        self._vertexNum = 0
        self._arcNum = 0
        self._vertices = [None for i in range(0, max_vertex)]
        self._arcs = [[float("inf") for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        for i in range(max_vertex):
            self._arcs[i][i] = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1

    def locateVertex(self, v):
        for i in range(self._vertexNum):
            if v == self._vertices[i].data:
                return i
        return -1

    def addEdge(self, v, w, weight):
        i = self.locateVertex(v)
        if i == -1:
            self.addVertex(v)
            i = self._vertexNum - 1
        j = self.locateVertex(w)
        if j == -1:
            self.addVertex(w)
            j = self._vertexNum - 1
        self._arcs[i][j] = weight
        self._arcs[j][i] = weight
        self._arcNum += 1   ##############

    def create(self):
        n, e = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(n)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(e)):
            a, b, weight = input().split()
            self.addEdge(a, b, float(weight))

    def degree(self, v):
        i = self.locateVertex(v)
        count = 0
        for j in range(self._vertexNum):
            count += self._arcs[i][j] != 0 and self._arcs[i][j] != float("inf")
        return count

    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0,self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4.0f" % (self._arcs[i][j]), end=" ")
            print()


if __name__ == "__main__":
    g3 = UDNGraphMatrix()
    g3.addVertex('A')
    g3.addVertex('B')
    g3.addVertex('C')
    g3.addVertex('D')
    g3.addVertex('E')
    g3.addVertex('F')
    g3.addEdge('A', 'B', 10)
    g3.addEdge('A', 'C', 2)
    g3.addEdge('B', 'D', 7)
    g3.addEdge('D', 'E', 2)
    g3.addEdge('B', 'F', 5)
    g3.addEdge('E', 'F', 5)
    g3.graph_out()
    print("请输入任意一个顶点的值：", end=" ")
    print("该顶点的度值为：", g3.degree(input()))

