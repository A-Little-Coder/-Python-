from CircularQueue import CircularQueue


class Vertex:
    def __init__(self, data):
        self.data = data
        self.firstArc = None


class Arc:
    def __init__(self, adjacent, weight, next=None):
        self.adjacent = adjacent
        self.weight = weight
        self.nextArc = next


class DNGraphAdjList:
    def __init__(self):
        self._vertexNum = 0
        self._arcNum = 0
        self._vertices = []

    def locateVertex(self, v):
        for i in range(self._vertexNum):
            if v == self._vertices[i].data:
                return i
        return -1

    def addVertex(self, data):
        self._vertexNum += 1
        newVertex = Vertex(data)
        self._vertices.append(newVertex)

    def addEdge(self, v, w, cost):
        self._arcNum += 1
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        edge_node1 = Arc(j, cost, self._vertices[i].firstArc)
        self._vertices[i].firstArc = edge_node1

    def graph_out(self):
        for i in range(self._vertexNum):
            p = self._vertices[i].firstArc
            print(self._vertices[i].data, ":", end="  ")
            while p is not None:
                if p.nextArc is not None:
                    print(p.adjacent, end=" -> ")
                else:
                    print(p.adjacent, end=" ")
                p = p.nextArc
            print()

    def findIndegree(self):
        indegree = [0 for i in range(self._vertexNum)]
        for i in range(0, self._vertexNum):
            tArc = self._vertices[i].firstArc
            while tArc:
                indegree[tArc.adjacent] += 1
                tArc = tArc.nextArc
        return indegree

    def getEventEarly(self, eventEarly):
        vertexQueue = CircularQueue()  # 用于存放入度为0的顶点的队列
        topoOrder = []  # 拓扑序列
        indegree = self.findIndegree()
        # 所有入度为0的顶点入队列
        for i in range(self._vertexNum):
            if indegree[i] == 0:
                vertexQueue.append(i)
            eventEarly.append(0)  # 数组eventEarly初始化为全0
        while len(vertexQueue) > 0:
            vi = vertexQueue.serve()  # 出队队首顶点vi
            topoOrder.append(vi)  # vi 加入到拓扑序列
            vjnode = self._vertices[vi].firstArc  # vjnode为i号边链表中首结点
            while vjnode:
                vj = vjnode.adjacent
                indegree[vj] -= 1  # vi的所有邻接点v入度值减1
                if indegree[vj] == 0:
                    vertexQueue.append(vj)
                # 对vi的所有邻接点vj，更新最早发生时间
                eventEarly[vj] = max(eventEarly[vi] + vjnode.weight, eventEarly[vj])
                vjnode = vjnode.nextArc  # vjnode指向边链表中下一个结点
        return topoOrder

    def getEventLate(self, topoSort, eventLate):
        topoSort.pop()  # 从拓扑序列中删除最后的汇点
        # 对其余顶点按照逆拓扑序列依次求解最晚发生时间
        while len(topoSort) > 0:
            vj = topoSort.pop()
            # 以下求解vj的最晚开始时间
            vknode = self._vertices[vj].firstArc  # vknode为j号边链表中首结点
            # 若发现eventLate[vk] -| vj,vk | <eventLate[vj]，则更新eventLate[vj]为此更小者
            while vknode:
                vk = vknode.adjacent  # vk为vj的各个邻接点
                eventLate[vj] = min(eventLate[vk] - vknode.weight, eventLate[vj])
                vknode = vknode.nextArc  # vknode指向边链表中下一个结点

    def findCriticalActivity(self, eventEarly, eventLate):
        for vi in range(self._vertexNum):  # 对i号单链表进行遍历
            vjnode = self._vertices[vi].firstArc  # vjnode为i号单链表的首结点
            activityEarly = eventEarly[vi]  # 活动<vi,vj>的最早开始时间
            while vjnode:
                vj = vjnode.adjacent
                activityLate = eventLate[vj] - vjnode.weight  # <vi,vj>的最晚开始时间
                # 如果活动的最早、最晚开始时间相同，则输出
                if activityEarly == activityLate:
                    print('关键活动：', end='')
                    print('v' + str(self._vertices[vi].data) + '->v'
                          + str(self._vertices[vj].data) + '，长度:' + str(vjnode.weight))
                vjnode = vjnode.nextArc  # vjnode为i号单链表的下一个结点

    def getCriticalPath(self):
        eventEarly = []  # 存放各顶点的最早开始时间
        eventLate = []  # 存放各顶点的最晚开始时间
        # 调用改写的拓扑排序算法，获得拓扑序列，同时求得eventEarly
        topoSort = self.getEventEarly(eventEarly)
        if len(topoSort) < self._vertexNum:
            print('该有向网中包含环，因此没有关键路径，没有关键活动。')
            return
        # 初始化各个顶点vi的最晚开始时间都为汇点的最晚发生时间
        duration = eventEarly[topoSort[len(topoSort) - 1]]
        for i in range(self._vertexNum):
            eventLate.append(duration)
        # 获得各个顶点的最晚开始时间eventLate
        self.getEventLate(topoSort, eventLate)
        # 求解并输出各个关键活动
        self.findCriticalActivity(eventEarly, eventLate)


if __name__ == '__main__':
    g12 = DNGraphAdjList()
    edgeList = [('0', '1', 6), ('0', '2', 4), ('0', '3', 5), ('1', '4', 1),
                ('2', '4', 1), ('3', '5', 2), ('4', '6', 9),('4', '7', 7),
                ('5', '7', 4), ('6', '8', 2), ('7', '8', 4)]
    for i in range(9):
        g12.addVertex(str(i))
    for edge in edgeList:
        g12.addEdge(edge[0], edge[1], edge[2])
    g12.getCriticalPath()

