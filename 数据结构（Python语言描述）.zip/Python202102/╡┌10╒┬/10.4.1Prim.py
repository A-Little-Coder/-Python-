# 10.4.1 prim 算法
# 无向连通网采用邻接矩阵存储

class Vertex:
    def __init__(self, data=None):
        self.data = data

class CloseEdge:
    def __init__(self, lowcost, adjvertex):
        self.lowcost = lowcost
        self.adjvertex = adjvertex

class UDNGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [Vertex() for i in range(0, max_vertex)]
        self._arcs = [[float("inf") for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        for i in range(max_vertex):
            self._arcs[i][i] = 0
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1
        return self._vertexNum

    def addEdge(self, v, w, cost):
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        self._arcs[i][j] = int(cost)
        self._arcs[j][i] = int(cost)
        self._arcNum += 1   #

    def create(self):
        a, b = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(a)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(b)):
            a, b, weight = input().split()
            self.addEdge(a, b, weight)

    def locateVertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index

    def prim(self, start):
        print('组成最小生成树的边依次为：')
        # 初始化closedges数组，closedges[i].lowcost即为边(start,i)的权值，
        # 在邻接矩阵结构下，即为矩阵第start行，第i列的元素
        closedges = [None for i in range(self._vertexNum)]
        for i in range(self._vertexNum):
            closedges[i] = CloseEdge(self._arcs[start][i], start)
        # 起点start的对应lowcost赋值为0，相当于是已加入生成树的标记
        closedges[start].lowcost = 0
        for edge_no in range(1, self._vertexNum):
            # 调用getMin函数获得closedges[i].lowcost中最小值对应的新顶点v
            v = self.getMin(closedges)
            u = closedges[v].adjvertex  # u为该最短边的已在生成树中的顶点
            # 输出一条生成树的边(u,v)
            print((self._vertices[u].data, self._vertices[v].data, self._arcs[u][v]))
            # 将v顶点的对应lowcost值赋值为0，相当于置已加入生成树的标记
            closedges[v].lowcost = 0
            # 更新其他顶点的closedges值，如果边(v,i)的权值小于原closedges[i].lowcost，
            # 则closedges[i].lowcost更新为(v,i)的权值，closedges[i].adjvertex更新为v，
            # 已加入生成树的顶点对应lowcost值为0，if条件不成立，closedges不更新
            for i in range(self._vertexNum):
                if self._arcs[v][i] < closedges[i].lowcost:
                    closedges[i] = CloseEdge(self._arcs[v][i], v)

    ##########################
    # 获取权值最小的边的方法
    ##########################

    def getMin(self, closedge):
        i = 0
        minWeight = float("inf")
        for i in range(self._vertexNum):
            if closedge[i].lowcost !=0 and closedge[i].lowcost < minWeight:
                minWeight = closedge[i].lowcost
                v = i
        return v


if __name__ == "__main__":
    g8 = UDNGraphMatrix()
    edgeList =[('0', '1', 4), ('0', '5', 2), ('0', '4', 3),
               ('1', '2', 2), ('1', '5', 6), ('2', '5', 5),
               ('2', '3', 6), ('3', '5', 3), ('3', '4', 7), ('4', '5', 1)]
    for i in range(6):
        g8.addVertex(str(i))
    for edge in edgeList:
        g8.addEdge(edge[0], edge[1], edge[2])
    g8.prim(0)

