# 10.5单源点最短路径和每对顶点间的最短路径
# 有向图 G9邻接矩阵下 dijkstra算法
# 有向图 G10邻接矩阵下 floyd算法

import sys

class Vertex:
    def __init__(self, data=None):
        self.data = data

##################################################################
# 图初始化时有个最大顶点数，邻接矩阵的最大阶数随之确定，一旦顶点数超出，则出错

class DNGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [Vertex() for i in range(0, max_vertex)]
        self._arcs = [[float("inf") for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        for i in range(max_vertex):
            self._arcs[i][i] = 0
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1
        return self._vertexNum

    def addEdge(self, v, w, cost):
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        self._arcs[i][j] = int(cost)
        self._arcNum += 1   ##############


    def locateVertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index



    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0,self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4d" % (self._arcs[i][j]), end=" ")
            print()



    def findMinDist(self, solved, distance):
        minDist = float("inf")
        i = 0
        j = 0
        while i < self._vertexNum:
            if not solved[i] and distance[i] < minDist:
                j = i
                minDist = distance[j]
            i = i + 1
        solved[j] = True
        return j

    def dijkstra(self, source):
        distance = [self._arcs[source][i] for i in range(self._vertexNum)]
        # 最短路径长度
        pre = [source for i in range(self._vertexNum)]
        # 存放到达i号顶点的最短路径中i号顶点的前驱
        solved = [False for i in range(self._vertexNum)]
        # 模拟S集合，记录顶点是否已求得最短路径,S中的顶点其标记为True
        solved[source] = True
        for count in range(self._vertexNum):
            j = self.findMinDist(solved, distance)
            # 找到一条以j为终点的最短路径
            for i in range(self._vertexNum):
                if not solved[i]:
                    if self._arcs[j][i] < float("inf") \
                            and distance[j] + self._arcs[j][i] < distance[i]:
                        distance[i] = distance[j] + self._arcs[j][i]
                        pre[i] = j
        self.printShortest(distance, pre, solved, source)

    def printShortest(self, distance, pre, solved, start):
        path = []
        v = 0
        while v < self._vertexNum:
            if solved[v] and v != start:
                print('最短路径', end=" ")
                path.append(v)  # 添加路径终点
                former = pre[v]  # 获取前一个顶点的下标
                while former != start:
                    path.append(former)
                    former = pre[former]
                path.append(start)
                while len(path) > 1:
                    print(self._vertices[path.pop()].data, '->', end='')
                print(self._vertices[path.pop()].data, end='')
                print('，长度为：', distance[v])
            v = v + 1

    def floyd(self):
        # 生成最短路径长度矩阵D矩阵
        d = [[0 for i in range(self._vertexNum)]
             for i in range(self._vertexNum)]
        # 生成最短路径矩阵P矩阵
        p = [[-1 for i in range(self._vertexNum)]
             for i in range(self._vertexNum)]
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                d[i][j] = self._arcs[i][j]  # 初始化D矩阵
                # 初始化P矩阵
                if self._arcs[i][j] < float("inf") and i != j:
                    p[i][j] = i
                else:
                    p[i][j] = -1  #

        # 依次经过顶点k，判断加入顶点k是否可以得到顶点i到顶点j的更短路径
        for k in range(self._vertexNum):
            for i in range(self._vertexNum):
                for j in range(self._vertexNum):
                    if i != j and d[i][k] + d[k][j] < d[i][j]:
                        d[i][j] = d[i][k] + d[k][j]
                        p[i][j] = p[k][j]

        self.printAllShortest(d, p)
        return d

    def printAllShortest(self, d, p):
        path = []
        for start in range(self._vertexNum):
            for end in range(self._vertexNum):
                # 存在路径，即start与end不同，且路径长度不为无穷大
                if d[start][end] < float("inf") and start != end:
                    print("顶点" + self._vertices[start].data + "到顶点" +
                          self._vertices[end].data + "的最短路径：", end="")
                    # 将start至end的路径逆向存储在Path列表中。
                    j = end
                    while j != start and j != -1:
                        path.append(j)
                        j = p[start][j]
                    path.append(start)
                    # 逆序输出path中的各个顶点
                    while len(path) > 1:
                        print(self._vertices[path.pop()].data, end="->")
                    print(self._vertices[path.pop()].data, end="")
                    print("，长度为：" + str(d[start][end]))


if __name__ == "__main__":
    g9 = DNGraphMatrix()
    edgeList = [('0', '1', 5), ('0', '2', 3), ('0', '4', 2),
                ('1', '2', 2), ('1', '3', 6), ('2', '1', 1),
                ('2', '3', 2), ('4', '1', 6), ('4', '2', 10), ('4', '3', 4)]
    for i in range(5):
        g9.addVertex(str(i))
    for edge in edgeList:
        g9.addEdge(edge[0], edge[1], edge[2])
    print("g9以顶点0为源点的最短路径：")
    g9.dijkstra(0)

    g10 = DNGraphMatrix()
    edgeList = [('0', '1', 1), ('0', '3', 4), ('1', '2', 9), ('1', '3', 2),
                ('2', '0', 3), ('2', '1', 5), ('2', '3', 8), ('3', '2', 6)]
    for i in range(4):
        g10.addVertex(str(i))
    for edge in edgeList:
        g10.addEdge(edge[0], edge[1], edge[2])
    print("\ng10中每对顶点间的最短路径：")
    g10.floyd()



