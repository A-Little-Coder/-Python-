# 10.3.3 深度优先和广度优先搜索的应用
# 例10.3 判断无向图是否有回路（深度）
# 例10.4 判断无向图是否有回路（广度）
# 假设无向图采用邻接矩阵表示
from CircularQueue import CircularQueue


class Vertex:
    def __init__(self, data):
        self.data = data


# 图初始化时有个最大顶点数，邻接矩阵的最大阶数随之确定，一旦顶点数超出，则出错
class UDGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [None for i in range(0, max_vertex)]
        self._arcs = [[0 for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1

    def addEdge(self, v, w):
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        self._arcs[i][j] = 1
        self._arcs[j][i] = 1  # 有向图时去掉此赋值语句
        self._arcNum += 1

    def create(self):
        a, b = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(a)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(b)):
            a, b = input().split()
            self.addEdge(a, b)

    def locateVertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index

    def degree(self, v):
        i = self.locateVertex(v)
        count = 0
        for j in range(self._vertexNum):
            count += self._arcs[i][j] != 0 and self._arcs[i][j] != float("inf")
        return count

    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0, self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4d" % (self._arcs[i][j]), end=" ")
            print()

    def firstAdjVertex(self, v):
        # 得到顶点v的第一个邻接点
        for w in range(self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def nextAdjVertex(self, v, adjacent):
        # 得到顶点v相对于adjacent的下一个邻接点
        for w in range(adjacent + 1, self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def visitVertex(self, v):
        print(self._vertices[v].data, end=' ')

    def has_loop_ud(self):
        visited = [0 for i in range(self._vertexNum)]
        pre = [-1 for i in range(self._vertexNum)]
        for v in range(self._vertexNum):
            if visited[v] == 0:
                if self.dfs_loop_ud(v, visited, pre):
                    return True
        return False

    def dfs_loop_ud(self, u, visited, pre):
        visited[u] = 1
        k = self.firstAdjVertex(u)  # k为u的第一个邻接点
        while k != -1:
            # k已被访问，且u不是由k访问而来
            if visited[k] == 1 and pre[u] != k:
                return True  # 图中有环
            # 从k开始深度遍历并判断该部分子图是否有环
            elif visited[k] == 0:
                pre[k] = u  # 记录顶点k的前驱
                result = self.dfs_loop_ud(k, visited, pre)
                if result:
                    return True
            k = self.nextAdjVertex(u, k)  # 查找u的下一个邻接点
        return False

    # for 无向图,有向图无法用广度优先搜索遍历判断是否有回路。
    def has_loop_bfs_ud(self, u):
        visited = [False for i in range(self._vertexNum)]
        q = CircularQueue()
        q.append(u)  # 顶点u入队
        visited[u] = True  # 顶点u置访问标记
        while not q.empty():
            pre = q.serve()  # 出队pre
            i = self.firstAdjVertex(pre)  # 找到pre的第一个邻接点i
            while i != -1:
                if not visited[i]:  # 如果该顶点未访问过
                    q.append(i)  # 入队i
                    visited[i] = True  # 置访问标记
                    j = self.firstAdjVertex(i)  # 找到i的邻接点j
                    while j != -1:
                        if j != pre and visited[j]:  # 如果j不是pre且已被访问则存在环
                            return True
                        j = self.nextAdjVertex(i, j)  # 继续找i的下一个邻接点j
                i = self.nextAdjVertex(pre, i)  # 找到pre的下一个邻接点i
        return False




if __name__ == "__main__":
    g = UDGraphMatrix()
    g.addVertex('A')
    g.addVertex('B')
    g.addVertex('C')
    g.addVertex('D')
    g.addVertex('E')
    g.addVertex('F')
    g.addEdge('A', 'B')
    g.addEdge('B', 'C')
    g.addEdge('C', 'D')
    g.addEdge('A', 'E')
    g.addEdge('D', 'F')
    g.addEdge('D', 'E')  # 有回路

    if g.has_loop_ud():
        print("有回路")
    else:
        print("没有回路")

    if g.has_loop_bfs_ud(0):
       print("有回路")
    else:
       print("没有回路")


