# 10.3.3 深度优先和广度优先搜索的应用
# 例 10.2判断一个有向图中是否有回路
# 假设有向图采用邻接矩阵表示
class Vertex:
    def __init__(self, data):
        self.data = data


# 图初始化时有个最大顶点数，邻接矩阵的最大阶数随之确定，一旦顶点数超出，则出错
class DGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [None for i in range(0, max_vertex)]
        self._arcs = [[0 for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1

    def addEdge(self, v, w):
        i = self.locateVertex(v)
        j = self.locateVertex(w)
        self._arcs[i][j] = 1
        self._arcNum += 1

    def create(self):
        a, b = input("请输入顶点数和边数：").split()
        print("请分别输入图的各个顶点:")
        for i in range(int(a)):
            self.addVertex(input())
        print("请分别输入图的各条边的信息:如 A B 1")
        for i in range(int(b)):
            a, b = input().split()
            self.addEdge(a, b)

    def locateVertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index

    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0, self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4d" % (self._arcs[i][j]), end=" ")
            print()

    def firstAdjVertex(self, v):
        # 得到顶点v的第一个邻接点
        for w in range(self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def nextAdjVertex(self, v, adjacent):
        # 得到顶点v相对于adjacent的下一个邻接点
        for w in range(adjacent + 1, self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def visitVertex(self, v):
        print(self._vertices[v].data, end=' ')

    def has_loop_dg(self):
        visited = [0 for i in range(self._vertexNum)]
        for v in range(self._vertexNum):
            if visited[v] == 0:
                if self.dfs_loop_dg(visited, v):
                    return True
        return False

    def dfs_loop_dg(self, visited, u):
        visited[u] = 1
        k = self.firstAdjVertex(u)
        while k != -1:
            if visited[k] == 1:
                # 从k开始的遍历正在进行中
                return True
            elif visited[k] == 0:
                result = self.dfs_loop_dg(visited, k)
                # 从k开始深度遍历并判断该部分子图是否有环
                if result:
                    return True
            k = self.nextAdjVertex(u, k)
        visited[u] = 2  # 表示v顶点开始的遍历已经结束
        return False


if __name__ == "__main__":
    g = DGraphMatrix()
    g.addVertex('A')
    g.addVertex('B')
    g.addVertex('C')
    g.addVertex('D')
    g.addVertex('E')
    g.addVertex('F')
    g.addEdge('A', 'B')
    g.addEdge('B', 'C')
    g.addEdge('C', 'D')
    g.addEdge('E', 'A')
    g.addEdge('D', 'F')
    g.addEdge('F', 'C')  # 有回路
    g.graph_out()
    print(g.has_loop_dg())
