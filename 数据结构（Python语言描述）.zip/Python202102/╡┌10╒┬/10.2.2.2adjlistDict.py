# 10.2.2.2 无向网邻接字典表示
# 本程序对G3进行测试
# 假设顶点值为字符，Vertex类存储顶点信息，data字段存储顶点的值，connetedTo是存放它的邻接顶点的字典，如
# 邻接表为一个字典，存放所有顶点信息

class Vertex:
    def __init__(self, key, entry=None):
        """顶点对象三个属性的初始化"""
        self.id = key
        self.data = entry
        self.connectedTo = {}

    def getConnections(self):
        """ 获得当前顶点的所有邻接点"""
        return self.connectedTo.keys()

    def addNeighbor(self, nbr, weight):
        """为当前顶点增加一条到nbr的权值为weight的边"""
        self.connectedTo[nbr] = weight

    def __str__(self):
        """顶点对象的输出格式，仅输出顶点值和以它出发的边的终点和权值"""
        # return str(self.data+", " +str({(x, y) for (x, y) in self.connectedTo.items()}))
        return str(self.data + ", " + str(self.connectedTo))

    def getWeight(self, nbr):
        """获得当前顶点到nbr的边的权值"""
        return self.connectedTo[nbr]

    def getValue(self):
        """#获得当前顶点的值"""
        return self.data

    def getId(self):
        """#获得当前顶点的标识"""
        return self.id

# {'A':('A',{'B’:4,’F’:2}), ’B’:(‘B’,{'A':4,'F’:6}),'F':('F',{'A’:2, ’B’:6})  }
class UDNGraphAdjDict:
    def __init__(self):
        self._vertices = {}
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, key, entry=None):
        newVertex = Vertex(key, entry)      # 生成Vertex对象
        self._vertices[key] = newVertex
        self._vertexNum = self._vertexNum + 1

    def addEdge(self, a, b, weight=0):
        if a not in self._vertices:
            self.addVertex(a)
        if b not in self._vertices:
            self.addVertex(b)
        self._vertices[a].addNeighbor(b, weight)
        self._vertices[b].addNeighbor(a, weight)
        self._arcNum += 1

    def __iter__(self):
        return iter(self._vertices.values())

    def graph_out(self):
        print("该图的邻接字典表示为：")
        for (vertexId, vertex) in self._vertices.items():
            print(vertexId, vertex)


if __name__ == "__main__":
    g3 = UDNGraphAdjDict()
    g3.addVertex('A', "苏州")
    g3.addVertex('B', "广州")
    g3.addVertex('C', "南京")
    g3.addVertex('D', "无锡")
    g3.addVertex('E', "常州")
    g3.addVertex('F', "上海")
    g3.addEdge('A', 'B', 10)
    g3.addEdge('A', 'C', 2)
    g3.addEdge('B', 'D', 7)
    g3.addEdge('B', 'F', 5)
    g3.addEdge('D', 'E', 2)
    g3.addEdge('E', 'F', 5)
    g3.graph_out()


