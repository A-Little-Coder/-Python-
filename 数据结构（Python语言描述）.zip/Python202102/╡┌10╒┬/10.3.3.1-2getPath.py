# 10.3.3 深度优先和广度优先搜索的应用
# 例 10.1 图中顶点u到顶点v的所有简单路径
# 例 10.5 图中顶点u到顶点v的最短路径
# 假设图采用邻接矩阵表示

from CircularQueue import CircularQueue


class Vertex:
    def __init__(self, data):
        self.data = data

# 图初始化时有个最大顶点数，邻接矩阵的最大阶数随之确定，一旦顶点数超出，则出错
class UDGraphMatrix:
    def __init__(self, max_vertex=32):
        self._vertices = [None for i in range(0, max_vertex)]
        self._arcs = [[0 for i in range(0, max_vertex)]
                     for j in range(0, max_vertex)]
        self._arcNum = 0
        self._vertexNum = 0

    def addVertex(self, data):
        newVertex = Vertex(data)
        self._vertices[self._vertexNum] = newVertex
        self._vertexNum += 1

    def addEdge(self, v, w):
        i = self.locate_vertex(v)
        j = self.locate_vertex(w)
        self._arcs[i][j] = 1
        self._arcs[j][i] = 1  # 有向图时去掉此赋值语句
        self._arcNum += 1

    def locate_vertex(self, v):
        index = 0
        while self._vertices[index].data != v and \
                index < self._vertexNum:
            index = index + 1
        return index

    def graph_out(self):
        print("该图的顶点为：")
        for i in range(0,self._vertexNum):
            print(self._vertices[i].data, end=" ")
        print()
        print("该图的邻接矩阵为：")
        for i in range(self._vertexNum):
            for j in range(self._vertexNum):
                if self._arcs[i][j] == float("inf"):
                    print("%4s" % ('#'), end=" ")
                else:
                    print("%4d" % (self._arcs[i][j]), end=" ")
            print()

    def firstAdjVertex(self, v):
        # 得到顶点v的第一个邻接点
        for w in range(self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def nextAdjVertex(self, v, adjacent):
        # 得到顶点v相对于adjacent的下一个邻接点
        for w in range(adjacent+1, self._vertexNum):
            if self._arcs[v][w] == 1:
                return w
        return -1

    def path(self, a, b):   # 例10.1
        visited = [0 for i in range(self._vertexNum)]  # 访问数组初始化
        way = [-1 for i in range(self._vertexNum)]     # way记录a到b的路径
        self.dfs_path(a, b, way, 0, visited)

    def dfs_path(self, u, v, path, start, visited):
        """求解u到v的所有路径并输出，路径从path数组的start位置开始存放"""
        path[start] = u    # 将u顶点放在path的第start位置
        visited[u] = True
        k = self.firstAdjVertex(u)
        while k != -1:
            if not visited[k]:
                if k == v:  # 已到达终点，则输出路径
                    start += 1
                    path[start] = v
                    for index in range(0, start + 1):
                        print(path[index], end=" ")
                    print()
                    start -= 1
                else:
                    # 求出k到v的路径，路径从path数组中start+1位置开始存放
                    self.dfs_path(k, v, path, start + 1, visited)
            k = self.nextAdjVertex(u, k)
        # 恢复该顶点的未访问标记，使得u在其它路径中可重新使用
        visited[u] = False

    def bfs_path(self, u, v): # 例10.5
        q = CircularQueue()
        visited = [0 for i in range(self._vertexNum)]
        pre = [-1 for i in range(self._vertexNum)]	# 记录遍历过程中每个顶点从何而来
        visited[u] = True
        q.append(u)
        while not q.empty():
            t = q.serve()
            i = self.firstAdjVertex(t)
            while i != -1:
                if not visited[i]:
                    if i == v:					# 如果广度遍历到达了终点v
                        pre[v] = t 			# 置终点v的前驱为t
                        self.out_path(u, v, pre)	# 调用out_path输出u到v的最短路径
                        return True
                    visited[i] = True
                    q.append(i)
                    pre[i] = t					# 置顶点i的前驱
                i = self.nextAdjVertex(t, i)
        return False

    def out_path(self, u, v, pre):
        lst = []
        while v != u:
            lst.append(v)
            v = pre[v]
        lst.append(u)
        for i in range(len(lst) - 1, -1, -1):
            print(lst[i], end=" ")


if __name__ == "__main__":
    g = UDGraphMatrix()
    g.addVertex('0')
    g.addVertex('1')
    g.addVertex('2')
    g.addVertex('3')
    g.addVertex('4')
    g.addVertex('5')
    g.addVertex('6')
    g.addVertex('7')
    g.addVertex('8')
    g.addEdge('0', '1')
    g.addEdge('0', '5')
    g.addEdge('1', '2')
    g.addEdge('2', '3')
    g.addEdge('2', '5')
    g.addEdge('4', '5')
    g.addEdge('4', '6')
    g.addEdge('4', '8')
    g.addEdge('5', '6')
    g.addEdge('5', '7')
    g.addEdge('6', '7')
    g.graph_out()
    print("所有路径：")
    g.path(0, 8)
    print("最短路径：")
    g.bfs_path(0, 8)
