# 4.3.2 p111
from AbstractStack import AbstractStack


class DynamicArrayStack(AbstractStack):
    INCREMENT = 10								# 栈的容量增量

    def __init__(self, init_size=0):
        super().__init__()
        self._capacity = init_size						# 栈容量赋值为初始容量
        # 生成容量为_capacity的列表
        self._entry = [None for x in range(0, self._capacity)]
        self._top = -1								# 栈顶位置初始化为-1

    def empty(self):
        return self._top == -1						# 判断栈是否为空

    def __len__(self):
        return self._top + 1  				# 栈顶指示器增1

    def push(self, item):
        if self._top >= self._capacity - 1:
            self._resize()					# 栈原空间用完，调用_resize
        self._top += 1						# 栈顶指示器增1
        self._entry[self._top] = item			# item元素入栈

    def _resize(self):
        self._capacity += self. INCREMENT			# 栈容量递增INCREMENT
        temp = [None for x in range(0, self._capacity)]	# 生成新的更大列表
        for i in range(0, self._capacity - self. INCREMENT):
            temp[i] = self._entry[i]			# 原来的栈元素依次复制到新列表中
        self._entry = temp					# 将新列表作为栈的容器

    def pop(self):
        if self.empty():
            raise Exception("栈为空")
        else:
            item = self._entry[self._top]		# 获得栈顶元素
            self._top -= 1					# 栈顶位置下移
            return item					# 返回栈顶元素

    def get_top(self):
        if self.empty():
            raise Exception("栈为空")
        else:
            return self._entry[self._top]


    def traverse(self):
        if self.empty():
            print("栈为空")
            return
        else:
            for i in range(0, self._top + 1):
                print(self._entry[i], end='  ')


if __name__ == "__main__":
    s = DynamicArrayStack()
    s.push(3)
    s.push(4)
    s.pop()
    s.push(5)
    s.push(6)
    s.push(7)
    s.push(8)
    s.push(9)
    s.push(10)
    print(len(s))
    print(s.get_top())
    s.traverse()
