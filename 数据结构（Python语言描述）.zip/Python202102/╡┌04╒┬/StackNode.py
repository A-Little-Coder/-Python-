# 4.4 p113
class StackNode:
    def __init__(self, entry, link=None):
        self.entry = entry
        self.next = link