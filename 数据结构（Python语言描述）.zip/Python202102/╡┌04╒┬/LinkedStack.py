# 4.4 p113
from StackNode import StackNode


class LinkedStack:
    def __init__(self):
        self._top = None

    def empty(self):
        return self._top is None

    def __len__(self):
        p = self._top
        count = 0
        while p is not None:
            count += 1
            p = p.next
        return count

    def push(self, item):
        new_top = StackNode(item, self._top)
        self._top = new_top

    def pop(self):
        if self.empty():
            # print("栈为空，无法出栈")
            return None
        else:
            old_top = self._top
            self._top = self._top.next
            item = old_top.entry
            del old_top
            return item

    def get_top(self):
        if self.empty():
            print("栈为空，无法读取栈顶元素")
            return None
        else:
            return self._top.entry

    def traverse(self):
        if self.empty():
            print("栈为空")
            return
        else:
            print("从栈顶到栈底元素依次为：")
            p = self._top
            while p is not None:
                print(p.entry, end=" ")
                p = p.next
            print()

    def __str__(self):
        lst = []
        p = self._top
        while p is not None:
            lst.append(p.entry)
            p = p.next
        return " ".join(str(i) for i in lst)


if __name__ == "__main__":
    s = LinkedStack()
    s.push(3)
    s.push(4)
    s.push(3)
    s.push(5)
    s.push(6)
    s.traverse()
    print(s)
