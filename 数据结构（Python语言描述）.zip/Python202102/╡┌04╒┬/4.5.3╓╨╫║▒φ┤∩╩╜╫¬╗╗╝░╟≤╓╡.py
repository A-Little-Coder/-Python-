# 4.5.3 123-126
from ArrayStack import ArrayStack
operator = {'+', '-', '*', '/', '(', ')', '#'}						# 算符集合
priority = {'*': 4, '/': 4, '+': 3, '-': 3, '(': 2, ')': 2, '#': 1}		# 算符优先级字典


def trans_infix_suffix(infix_ex):  # infix_ex为需转换的中缀表达式
    st = ArrayStack()
    st.push('#')
    exp = []
    for m in tokens(infix_ex):
        # tokens是获得infix_ex串中各逻辑部分的生成器
        if m not in operator:  # 如果theta2是操作数
            exp.append(m)   # 操作数加入后缀表达式列表
        elif m == '(':  # 左括号进栈
            st.push(m)
        else:
            theta1 = st.get_top()  # theta1为栈顶算符
            theta2 = m      # theta2为当前算符
            while theta1 != '#' or theta2 != '#':  # 当theta1和theta2不全是#
                # 当前算符theta2优先权高于栈顶，theta2进栈
                # 跳出内循环，继续读下一符号
                if priority[theta1] < priority[theta2]:
                    st.push(theta2)
                    break
                # 右括号遇栈顶左括号，左括号出栈，跳出内循环，继续读下一符号
                elif theta1 == "(" and theta2 == ")":
                    st.pop()
                    break
                # 栈顶优先级数值≥theta2的优先级数值，出栈栈顶加入后缀表达式
                else:
                    st.pop()
                    exp.append(theta1)
                    theta1 = st.get_top()  # theta1为新栈顶算符 ，继续内层循环
    return exp


def tokens(text_line):
    i, t_len = 0, len(text_line)
    while i < t_len:
        if text_line[i].isspace():  # 遇到空格
            i += 1
            continue
        if text_line[i] in operator:  # 遇到算符
            yield text_line[i]       # 生成算符
            i += 1
            continue
        j = i + 1   # 遇到操作数
        while j < t_len and not text_line[j].isspace() and \
                text_line[j] not in operator:
            if (text_line[j] == 'e' or text_line[j] == 'E') \
                    and j+1 < t_len and text_line[j+1] == '-':
                j += 1      # 遇到负指数
            j += 1
        yield text_line[i:j]  # 生成操作数子串
        i = j
    yield '#'       # 串读完时生成结束符"#"


def postfix2(lst):
    st = ArrayStack()
    i = 0
    while i < len(lst):
        m = lst[i]
        if m not in operator:
            st.push(float(m))
        else:
            y = st.pop()
            x = st.pop()
            z = 0
            op = m
            if op == '+':
                z = x + y
            elif op == '-':
                z = x - y
            elif op == '*':
                z = x * y
            elif op == '/':
                z = x / y
            st.push(z)
        i += 1
    return st.pop()


def calculate(op, opnd):
    """对opnd栈顶的2个操作数进行op运算，并将运算结果入栈"""
    q = float(opnd.pop())
    p = float(opnd.pop())
    if op == "+":
        r = p + q
    elif op == "-":
        r = p - q
    elif op == "*":
        r = p * q
    elif op == "/":
        r = p / q
    opnd.push(r)


def calc_infix(infix_ex):
    opnd = ArrayStack()						# 存放操作数
    optr = ArrayStack()						# 存放算符
    optr.push('#')
    for m in tokens(infix_ex):
        # tokens是获得infix_ex串中各逻辑部分的生成器
        if m not in operator:
            opnd.push(m)
        elif m == '(':  # 左括号进栈
            optr.push(m)
        else:
            theta1 = optr.get_top()			# theta1为栈顶算符
            theta2 = m						# theta2为当前算符
            while theta1 != '#' or theta2 != '#':
                # 当前算符theta2优先权高于栈顶，theta2进栈，跳出内循环，继续读下一符号
                if priority[theta1] < priority[theta2]:
                    optr.push(theta2)
                    break
                # 当前右括号遇栈顶左括号，左括号出栈，跳出内循环，继续读下一符号
                elif theta1 == "(" and theta2 == ")":
                    optr.pop()
                    break
                # theta1优先级数值≥theta2优先级数组，完成theta1运算，
                # 运算结果入opnd栈，读取新的theta1，继续内层循环
                else:
                    theta1 = optr.pop()
                    calculate(theta1, opnd)     # 调用calculate完成运算
                    theta1 = optr.get_top()  # theta1为新的栈顶算符，继续内层循环
    return opnd.pop()


if __name__ == "__main__":
    infix_ex1 = "5+6*(1+2)-4"
    infix_ex2 = "(3+5*1e2/40)*2"
    infix_ex2= "3.5*(20+4)-20/4"
    post_lst = trans_infix_suffix(infix_ex1)
    print(infix_ex1, "=>", post_lst, end=" ")
    print("=>", postfix2(post_lst))

    post_lst = trans_infix_suffix(infix_ex2)
    print(infix_ex2, "=>", post_lst, end=" ")
    print("=>", postfix2(post_lst))

    print(infix_ex1, '=', calc_infix(infix_ex1))
    print(infix_ex2, '=',calc_infix(infix_ex2))


