# 4.5.1 p116
from LinkedStack import StackNode,LinkedStack


def ReadFile(filename):
    f = open(filename)
    str = f.read()
    f.close()
    print("要判断括号匹配的源程序如下：")
    print(str)
    return str


def parentheses(text):
    pares = {'(',')', '[',']', '{','}'}
    i, text_len = 0, len(text)
    for i in range(0, text_len):
        if text[i] in pares:
            yield text[i], i


def bracket_match(text):    # p116
    open_pares = {'(', '[', '{'}					# 左括号集合
    opposite = {")": "(", "]": "[", "}": "{"}		# 表示配对关系的字典
    st = LinkedStack()						# 存储左括号的链栈，也可以是顺序栈
    for pr, i in parentheses(text):				# 对text里的每个括号及位置循环处理
        if pr in open_pares: 	# 遇左括号将括号及其位置作为元组入栈，继续循环
            st.push((pr, i))
        elif st.empty():			# 遇右括号，而栈空，说明没有与之配对的左括号
            print("多余右括号，位置", i, "对应括号为", pr)
            return False
        else:     						# 遇到右括号，栈非空
            prepr, j = st.pop()				# 出栈栈顶的左括号及位置
            if prepr != opposite[pr]:			# 不匹配，退出
                print("发现不匹配位置", j, i, "对应括号为", prepr, pr)
                return False
    if not st.empty():				# 文本串读完，栈不空，说明前面多了左括号
        prepr, j = st.pop()
        print("多余左括号，位置为", j, "括号为", prepr)
        return False
    else:
        print("所有括号全部配对")
        return True



if __name__ == "__main__":
    text = "{3*[A+(b*cd)]}"
    print(text)
    bracket_match(text)
    print("--------------------------")
    text = "3*A+(b*cd]+{5*a}"
    print(text)
    bracket_match(text)
    print("--------------------------")
    text = "3*A+(b*cd)dfg]+sfg"
    print(text)
    bracket_match(text)
    print("--------------------------")
    text = "{3*A+(b*cd)+5+e"
    print(text)
    bracket_match(text)
    print("--------------------------")
    s = LinkedStack()
    s.push(1)
    s.push(2)
    print(len(s))

    text = (ReadFile("example.cpp"))
    print(bracket_match(text), "\n----\n")
