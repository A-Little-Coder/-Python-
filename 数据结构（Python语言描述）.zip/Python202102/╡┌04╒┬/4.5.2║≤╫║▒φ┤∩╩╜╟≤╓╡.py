# 4.5.2 p118-119
from ArrayStack import  ArrayStack

def tokens(text):
    i, t_len = 0, len(text)
    while i < t_len:
        if text[i].isspace():  					# 遇到空格
            i += 1
        elif text[i] in operator:					# 遇到算符
            yield text[i]						# 生成算符
            i += 1
        else: 									# 遇到操作数
            j = i + 1
            while j < t_len and not text[j].isspace() and \
                    text[j] not in operator:		# 操作数包含多位的时候
                # 操作数用科学计数法表示，且遇到负指数
                if (text[j] == 'e' or text[j] == 'E') and \
                        j+1 < t_len and text[j+1] == '-':
                    j += 1
                j += 1
            yield text[i:j]  # 生成操作数子串
            i = j
    yield '#'       # 串读完时生成结束符#


operator = {'+', '-', '*', '/', '#'}  # 存储所有算符


def postfix(postfix_ex):
    st = ArrayStack()				# 操作数栈初始化
    for m in tokens(postfix_ex):		# 对tokens生成器获得的每个逻辑部分进行处理
        if m not in operator:
            st.push(float(m))		# 遇到操作数，则入栈
        else:
            if m == '#':			# 遇到结束符退出
                return st.pop()     # 返回运算结果
            opnd2 = st.pop()		# 遇到运算符，连续出栈2个元素
            opnd1 = st.pop()
            op = m
            result = 0
            if op == '+':			# 根据运算符不同，做不同的运算
                result = opnd1 + opnd2
            elif op == '-':
                result = opnd1 - opnd2
            elif op == '*':
                result = opnd1 * opnd2
            elif op == '/':
                result = opnd1 / opnd2
            st.push(result)			# 将运算结果入栈


def postfix2(lst):
    st = ArrayStack()
    i = 0
    while i < len(lst):
        m = lst[i]
        if m not in operator:
            st.push(float(m))
        else:
            y = st.pop()
            x = st.pop()
            z = 0
            op = m
            if op == '+':
                z = x + y
            elif op == '-':
                z = x - y
            elif op == '*':
                z = x * y
            elif op == '/':
                z = x / y
            st.push(z)
        i += 1
    return st.pop()


if __name__ == '__main__':
    postfix_ex = "1 2 4 * + 5-"
    print(postfix_ex, '===>', postfix(postfix_ex))
    postfix_ex =  "1 2 3.1 * + 5e-2 / "
    print(postfix_ex, '===>', postfix2(postfix_ex.split()))
